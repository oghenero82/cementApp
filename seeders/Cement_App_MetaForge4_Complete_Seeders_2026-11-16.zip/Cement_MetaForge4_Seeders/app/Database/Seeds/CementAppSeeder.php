<?php

declare(strict_types=1);

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

final class CementAppSeeder extends Seeder
{
    public function run()
    {
        (new \App\Database\Seeds\Cement\CementAppSeeder())->run();
    }
}
