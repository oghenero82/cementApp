<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementIncentivesSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_incentives',
            'name' => 'Supplier Benefits',
            'description' => 'Supplier incentives, entitlements and settlements',
        ];
    }
}
