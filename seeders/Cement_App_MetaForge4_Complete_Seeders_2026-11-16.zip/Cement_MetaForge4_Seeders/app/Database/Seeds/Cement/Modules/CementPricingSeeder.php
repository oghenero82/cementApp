<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementPricingSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_pricing',
            'name' => 'Pricing',
            'description' => 'Versioned customer and quantity tier pricing',
        ];
    }
}
