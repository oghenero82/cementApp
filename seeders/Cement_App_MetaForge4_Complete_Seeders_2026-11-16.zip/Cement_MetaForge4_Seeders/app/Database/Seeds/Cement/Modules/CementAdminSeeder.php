<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementAdminSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_admin',
            'name' => 'Configuration',
            'description' => 'Cement institution policies, audit and integrations',
        ];
    }
}
