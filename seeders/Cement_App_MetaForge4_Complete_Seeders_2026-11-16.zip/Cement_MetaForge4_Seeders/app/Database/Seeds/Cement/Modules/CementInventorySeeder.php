<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementInventorySeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_inventory',
            'name' => 'Warehouse & Inventory',
            'description' => 'Locations, stock, FIFO/weighted costs, counts and damages',
        ];
    }
}
