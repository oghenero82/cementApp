<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementSalesSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_sales',
            'name' => 'Sales & Receivables',
            'description' => 'Customer sales, payments and returns',
        ];
    }
}
