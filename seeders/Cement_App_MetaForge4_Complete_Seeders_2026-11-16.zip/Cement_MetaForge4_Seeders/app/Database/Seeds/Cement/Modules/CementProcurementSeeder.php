<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementProcurementSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_procurement',
            'name' => 'Procurement',
            'description' => 'Supplier entitlements, purchases, loading and clearing',
        ];
    }
}
