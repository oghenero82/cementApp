<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementFinanceSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_finance',
            'name' => 'Finance & Reporting',
            'description' => 'Expense and operational reports; reuse Accounting general ledger',
        ];
    }
}
