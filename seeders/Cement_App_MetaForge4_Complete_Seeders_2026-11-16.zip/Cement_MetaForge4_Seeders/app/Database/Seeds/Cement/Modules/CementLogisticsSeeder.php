<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Modules;

use App\Database\Seeds\Cement\Support\AbstractModuleSeeder;

final class CementLogisticsSeeder extends AbstractModuleSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_logistics',
            'name' => 'Fleet & Trips',
            'description' => 'Vehicles, drivers, trips with multiple destinations, fuel and maintenance',
        ];
    }
}
