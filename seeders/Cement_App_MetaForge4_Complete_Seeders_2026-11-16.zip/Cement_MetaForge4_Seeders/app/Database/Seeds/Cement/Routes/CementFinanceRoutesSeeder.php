<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementFinanceRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.expense.list',
                'name' => 'General Expense List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'expense',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'expenseDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.expense.new',
                'name' => 'General Expense New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'expense',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'expenseDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.expense.view',
                'name' => 'General Expense View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'expense',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'expenseDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.expense.edit',
                'name' => 'General Expense Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'expense',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'expenseDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.report.list',
                'name' => 'Report Definition List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'report',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'generationMode',
                    ],
                ],
            ],
            [
                'code' => 'cement.report.new',
                'name' => 'Report Definition New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'generationMode',
                    ],
                ],
            ],
            [
                'code' => 'cement.report.view',
                'name' => 'Report Definition View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'report',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'generationMode',
                    ],
                ],
            ],
            [
                'code' => 'cement.report.edit',
                'name' => 'Report Definition Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'generationMode',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_result.list',
                'name' => 'Stored Report Result List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'report_result',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'reportId',
                        'generatedAt',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_result.new',
                'name' => 'Stored Report Result New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report_result',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'reportId',
                        'generatedAt',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_result.view',
                'name' => 'Stored Report Result View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'report_result',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'reportId',
                        'generatedAt',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_result.edit',
                'name' => 'Stored Report Result Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report_result',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'reportId',
                        'generatedAt',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_delivery.list',
                'name' => 'Report Delivery List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'report_delivery',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_delivery.new',
                'name' => 'Report Delivery New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report_delivery',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_delivery.view',
                'name' => 'Report Delivery View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'report_delivery',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_delivery.edit',
                'name' => 'Report Delivery Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report_delivery',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_schedule.list',
                'name' => 'Report Schedule List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'report_schedule',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_schedule.new',
                'name' => 'Report Schedule New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report_schedule',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_schedule.view',
                'name' => 'Report Schedule View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'report_schedule',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.report_schedule.edit',
                'name' => 'Report Schedule Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'report_schedule',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_finance',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.reports.dashboard',
                'name' => 'Reports Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'reports',
                'targetRecordTypeCode' => 'report',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.finance.dashboard',
                'name' => 'Finance Overview',
                'mode' => 'open_layout',
                'layoutCode' => 'finance',
                'targetRecordTypeCode' => 'report',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
