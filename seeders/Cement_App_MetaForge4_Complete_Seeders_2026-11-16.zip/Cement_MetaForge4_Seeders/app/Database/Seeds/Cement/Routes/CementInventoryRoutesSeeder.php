<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementInventoryRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.inventory_location.list',
                'name' => 'Inventory Location List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_location',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_location.new',
                'name' => 'Inventory Location New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_location',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_location.view',
                'name' => 'Inventory Location View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_location',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_location.edit',
                'name' => 'Inventory Location Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_location',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stock.list',
                'name' => 'Inventory Stock List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_stock',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'stockCondition',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stock.new',
                'name' => 'Inventory Stock New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_stock',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'stockCondition',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stock.view',
                'name' => 'Inventory Stock View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_stock',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'stockCondition',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stock.edit',
                'name' => 'Inventory Stock Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_stock',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'stockCondition',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_movement.list',
                'name' => 'Inventory Movement List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_movement',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'productId',
                        'sourceRecordId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_movement.new',
                'name' => 'Inventory Movement New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_movement',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'productId',
                        'sourceRecordId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_movement.view',
                'name' => 'Inventory Movement View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_movement',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'productId',
                        'sourceRecordId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_movement.edit',
                'name' => 'Inventory Movement Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_movement',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'productId',
                        'sourceRecordId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_cost_layer.list',
                'name' => 'FIFO Cost Layer List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_cost_layer',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'stockId',
                        'sourceMovementId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_cost_layer.new',
                'name' => 'FIFO Cost Layer New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_cost_layer',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'stockId',
                        'sourceMovementId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_cost_layer.view',
                'name' => 'FIFO Cost Layer View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_cost_layer',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'stockId',
                        'sourceMovementId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_cost_layer.edit',
                'name' => 'FIFO Cost Layer Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_cost_layer',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'stockId',
                        'sourceMovementId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake.list',
                'name' => 'Stocktake List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_stocktake',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'countDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake.new',
                'name' => 'Stocktake New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_stocktake',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'countDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake.view',
                'name' => 'Stocktake View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_stocktake',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'countDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake.edit',
                'name' => 'Stocktake Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_stocktake',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'countDate',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake_line.list',
                'name' => 'Stocktake Line List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_stocktake_line',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'stocktakeId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake_line.new',
                'name' => 'Stocktake Line New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_stocktake_line',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'stocktakeId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake_line.view',
                'name' => 'Stocktake Line View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_stocktake_line',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'stocktakeId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_stocktake_line.edit',
                'name' => 'Stocktake Line Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_stocktake_line',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'stocktakeId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.stock_adjustment.list',
                'name' => 'Stock Adjustment List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'stock_adjustment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.stock_adjustment.new',
                'name' => 'Stock Adjustment New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'stock_adjustment',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.stock_adjustment.view',
                'name' => 'Stock Adjustment View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'stock_adjustment',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.stock_adjustment.edit',
                'name' => 'Stock Adjustment Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'stock_adjustment',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'locationId',
                        'productId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.damaged_goods.list',
                'name' => 'Damaged or Bad Goods List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'damaged_goods',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.damaged_goods.new',
                'name' => 'Damaged or Bad Goods New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'damaged_goods',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.damaged_goods.view',
                'name' => 'Damaged or Bad Goods View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'damaged_goods',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.damaged_goods.edit',
                'name' => 'Damaged or Bad Goods Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'damaged_goods',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_transfer.list',
                'name' => 'Inventory Transfer List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'inventory_transfer',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_transfer.new',
                'name' => 'Inventory Transfer New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_transfer',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_transfer.view',
                'name' => 'Inventory Transfer View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'inventory_transfer',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory_transfer.edit',
                'name' => 'Inventory Transfer Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'inventory_transfer',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_inventory',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.inventory.dashboard',
                'name' => 'Inventory Overview',
                'mode' => 'open_layout',
                'layoutCode' => 'inventory',
                'targetRecordTypeCode' => 'inventory_stock',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
