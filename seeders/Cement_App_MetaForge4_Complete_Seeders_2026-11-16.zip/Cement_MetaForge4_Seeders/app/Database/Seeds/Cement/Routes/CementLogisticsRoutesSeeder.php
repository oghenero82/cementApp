<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementLogisticsRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.vehicle.list',
                'name' => 'Vehicle List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'vehicle',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'registrationNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle.new',
                'name' => 'Vehicle New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'vehicle',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'registrationNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle.view',
                'name' => 'Vehicle View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'vehicle',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'registrationNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle.edit',
                'name' => 'Vehicle Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'vehicle',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'registrationNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip.list',
                'name' => 'Delivery Trip List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'trip',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'vehicleId',
                        'driverId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip.new',
                'name' => 'Delivery Trip New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'trip',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'vehicleId',
                        'driverId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip.view',
                'name' => 'Delivery Trip View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'trip',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'vehicleId',
                        'driverId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip.edit',
                'name' => 'Delivery Trip Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'trip',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'vehicleId',
                        'driverId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_destination.list',
                'name' => 'Trip Destination List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'trip_destination',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_destination.new',
                'name' => 'Trip Destination New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'trip_destination',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_destination.view',
                'name' => 'Trip Destination View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'trip_destination',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_destination.edit',
                'name' => 'Trip Destination Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'trip_destination',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'tripId',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.fuel_transaction.list',
                'name' => 'Fuel Transaction List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'fuel_transaction',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.fuel_transaction.new',
                'name' => 'Fuel Transaction New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'fuel_transaction',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.fuel_transaction.view',
                'name' => 'Fuel Transaction View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'fuel_transaction',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.fuel_transaction.edit',
                'name' => 'Fuel Transaction Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'fuel_transaction',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle_maintenance.list',
                'name' => 'Vehicle Maintenance List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'vehicle_maintenance',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle_maintenance.new',
                'name' => 'Vehicle Maintenance New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'vehicle_maintenance',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle_maintenance.view',
                'name' => 'Vehicle Maintenance View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'vehicle_maintenance',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.vehicle_maintenance.edit',
                'name' => 'Vehicle Maintenance Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'vehicle_maintenance',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_expense.list',
                'name' => 'Trip Expense List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'trip_expense',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_expense.new',
                'name' => 'Trip Expense New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'trip_expense',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_expense.view',
                'name' => 'Trip Expense View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'trip_expense',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.trip_expense.edit',
                'name' => 'Trip Expense Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'trip_expense',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_logistics',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.logistics.dashboard',
                'name' => 'Fleet Overview',
                'mode' => 'open_layout',
                'layoutCode' => 'logistics',
                'targetRecordTypeCode' => 'trip',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
