<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementIncentivesRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.supplier_incentive_scheme.list',
                'name' => 'Supplier Incentive Scheme List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier_incentive_scheme',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_scheme.new',
                'name' => 'Supplier Incentive Scheme New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_incentive_scheme',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_scheme.view',
                'name' => 'Supplier Incentive Scheme View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier_incentive_scheme',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_scheme.edit',
                'name' => 'Supplier Incentive Scheme Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_incentive_scheme',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive.list',
                'name' => 'Supplier Incentive Benefit List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier_incentive',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive.new',
                'name' => 'Supplier Incentive Benefit New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_incentive',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive.view',
                'name' => 'Supplier Incentive Benefit View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier_incentive',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive.edit',
                'name' => 'Supplier Incentive Benefit Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_incentive',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_receipt.list',
                'name' => 'Supplier Incentive Receipt List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier_incentive_receipt',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_receipt.new',
                'name' => 'Supplier Incentive Receipt New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_incentive_receipt',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_receipt.view',
                'name' => 'Supplier Incentive Receipt View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier_incentive_receipt',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_incentive_receipt.edit',
                'name' => 'Supplier Incentive Receipt Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_incentive_receipt',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_incentives',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
        ];
    }
}
