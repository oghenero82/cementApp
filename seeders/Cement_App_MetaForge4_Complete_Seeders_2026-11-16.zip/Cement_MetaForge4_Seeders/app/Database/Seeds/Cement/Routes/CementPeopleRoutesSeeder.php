<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementPeopleRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.staff_employment.list',
                'name' => 'Staff Employment List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'staff_employment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'personId',
                        'employeeNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_employment.new',
                'name' => 'Staff Employment New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'staff_employment',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'personId',
                        'employeeNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_employment.view',
                'name' => 'Staff Employment View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'staff_employment',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'personId',
                        'employeeNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_employment.edit',
                'name' => 'Staff Employment Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'staff_employment',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'personId',
                        'employeeNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll.list',
                'name' => 'Payroll Batch List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'payroll',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'periodStart',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll.new',
                'name' => 'Payroll Batch New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'payroll',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'periodStart',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll.view',
                'name' => 'Payroll Batch View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'payroll',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'periodStart',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll.edit',
                'name' => 'Payroll Batch Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'payroll',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'periodStart',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_item.list',
                'name' => 'Payroll Item List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'payroll_item',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'payrollId',
                        'employmentId',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_item.new',
                'name' => 'Payroll Item New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'payroll_item',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'payrollId',
                        'employmentId',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_item.view',
                'name' => 'Payroll Item View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'payroll_item',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'payrollId',
                        'employmentId',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_item.edit',
                'name' => 'Payroll Item Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'payroll_item',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'payrollId',
                        'employmentId',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_payment.list',
                'name' => 'Payroll Payment List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'payroll_payment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_payment.new',
                'name' => 'Payroll Payment New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'payroll_payment',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_payment.view',
                'name' => 'Payroll Payment View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'payroll_payment',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.payroll_payment.edit',
                'name' => 'Payroll Payment Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'payroll_payment',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_deduction.list',
                'name' => 'Staff Deduction Schedule List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'staff_deduction',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_deduction.new',
                'name' => 'Staff Deduction Schedule New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'staff_deduction',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_deduction.view',
                'name' => 'Staff Deduction Schedule View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'staff_deduction',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff_deduction.edit',
                'name' => 'Staff Deduction Schedule Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'staff_deduction',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_people',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.staff.dashboard',
                'name' => 'Staff Overview',
                'mode' => 'open_layout',
                'layoutCode' => 'people',
                'targetRecordTypeCode' => 'staff_employment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
