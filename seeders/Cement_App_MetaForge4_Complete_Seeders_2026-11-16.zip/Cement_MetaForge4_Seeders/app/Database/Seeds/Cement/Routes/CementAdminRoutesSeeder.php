<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementAdminRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.cement_branch.list',
                'name' => 'Branch List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'cement_branch',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_branch.new',
                'name' => 'Branch New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'cement_branch',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_branch.view',
                'name' => 'Branch View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'cement_branch',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_branch.edit',
                'name' => 'Branch Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'cement_branch',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_audit_event.list',
                'name' => 'Operational Audit Event List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'cement_audit_event',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_audit_event.new',
                'name' => 'Operational Audit Event New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'cement_audit_event',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_audit_event.view',
                'name' => 'Operational Audit Event View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'cement_audit_event',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_audit_event.edit',
                'name' => 'Operational Audit Event Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'cement_audit_event',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_admin',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.dashboard',
                'name' => 'Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.system.importer',
                'name' => 'System Importer',
                'mode' => 'open_layout',
                'layoutCode' => 'importer',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_system_admin_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_system_admin.dashboard',
                'name' => 'System Admin Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_system_admin_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_admin.dashboard',
                'name' => 'Administrator Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_admin_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_accountant.dashboard',
                'name' => 'Accountant Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_accountant_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_sales_manager.dashboard',
                'name' => 'Sales Manager Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_sales_manager_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_store_keeper.dashboard',
                'name' => 'Store Keeper Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_store_keeper_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_data_entry.dashboard',
                'name' => 'Data Entry Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_data_entry_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
            [
                'code' => 'cement.cement_driver.dashboard',
                'name' => 'Driver Dashboard',
                'mode' => 'open_layout',
                'layoutCode' => 'dashboard',
                'targetRecordTypeCode' => null,
                'targetPortalCode' => 'cement_driver_portal',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
