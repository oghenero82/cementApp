<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementMasterRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.person.list',
                'name' => 'Person List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'person',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'phone',
                        'email',
                    ],
                ],
            ],
            [
                'code' => 'cement.person.new',
                'name' => 'Person New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'person',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'phone',
                        'email',
                    ],
                ],
            ],
            [
                'code' => 'cement.person.view',
                'name' => 'Person View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'person',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'phone',
                        'email',
                    ],
                ],
            ],
            [
                'code' => 'cement.person.edit',
                'name' => 'Person Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'person',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'phone',
                        'email',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer.list',
                'name' => 'Customer List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'customer',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'companyName',
                        'phone',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer.new',
                'name' => 'Customer New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'companyName',
                        'phone',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer.view',
                'name' => 'Customer View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'customer',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'companyName',
                        'phone',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer.edit',
                'name' => 'Customer Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'companyName',
                        'phone',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier.list',
                'name' => 'Supplier List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'name',
                        'supplierNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier.new',
                'name' => 'Supplier New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                        'supplierNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier.view',
                'name' => 'Supplier View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                        'supplierNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier.edit',
                'name' => 'Supplier Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                        'supplierNumber',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_depot.list',
                'name' => 'Supplier Depot List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier_depot',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'supplierDepotCode',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_depot.new',
                'name' => 'Supplier Depot New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_depot',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'supplierDepotCode',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_depot.view',
                'name' => 'Supplier Depot View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier_depot',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'supplierDepotCode',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_depot.edit',
                'name' => 'Supplier Depot Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_depot',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'supplierDepotCode',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_product.list',
                'name' => 'Supplier Product Mapping List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier_product',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_product.new',
                'name' => 'Supplier Product Mapping New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_product',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_product.view',
                'name' => 'Supplier Product Mapping View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier_product',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_product.edit',
                'name' => 'Supplier Product Mapping Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_product',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.unit_of_measure.list',
                'name' => 'Unit of Measure List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'unit_of_measure',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'symbol',
                    ],
                ],
            ],
            [
                'code' => 'cement.unit_of_measure.new',
                'name' => 'Unit of Measure New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'unit_of_measure',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'symbol',
                    ],
                ],
            ],
            [
                'code' => 'cement.unit_of_measure.view',
                'name' => 'Unit of Measure View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'unit_of_measure',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'symbol',
                    ],
                ],
            ],
            [
                'code' => 'cement.unit_of_measure.edit',
                'name' => 'Unit of Measure Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'unit_of_measure',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'symbol',
                    ],
                ],
            ],
            [
                'code' => 'cement.product_category.list',
                'name' => 'Product Category List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'product_category',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'name',
                    ],
                ],
            ],
            [
                'code' => 'cement.product_category.new',
                'name' => 'Product Category New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'product_category',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                    ],
                ],
            ],
            [
                'code' => 'cement.product_category.view',
                'name' => 'Product Category View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'product_category',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                    ],
                ],
            ],
            [
                'code' => 'cement.product_category.edit',
                'name' => 'Product Category Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'product_category',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                    ],
                ],
            ],
            [
                'code' => 'cement.product.list',
                'name' => 'Product List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'product',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'name',
                        'categoryId',
                    ],
                ],
            ],
            [
                'code' => 'cement.product.new',
                'name' => 'Product New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'product',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                        'categoryId',
                    ],
                ],
            ],
            [
                'code' => 'cement.product.view',
                'name' => 'Product View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'product',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                        'categoryId',
                    ],
                ],
            ],
            [
                'code' => 'cement.product.edit',
                'name' => 'Product Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'product',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_master',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'name',
                        'categoryId',
                    ],
                ],
            ],
        ];
    }
}
