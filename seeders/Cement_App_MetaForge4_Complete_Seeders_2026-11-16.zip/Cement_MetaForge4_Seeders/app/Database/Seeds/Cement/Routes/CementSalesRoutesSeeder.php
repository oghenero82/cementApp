<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementSalesRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.customer_sales.list',
                'name' => 'Customer Sale List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'customer_sales',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'customerId',
                        'saleDate',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sales.new',
                'name' => 'Customer Sale New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_sales',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'customerId',
                        'saleDate',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sales.view',
                'name' => 'Customer Sale View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'customer_sales',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'customerId',
                        'saleDate',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sales.edit',
                'name' => 'Customer Sale Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_sales',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'customerId',
                        'saleDate',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_item.list',
                'name' => 'Customer Sale Item List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'customer_sale_item',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'saleId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_item.new',
                'name' => 'Customer Sale Item New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_sale_item',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'saleId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_item.view',
                'name' => 'Customer Sale Item View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'customer_sale_item',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'saleId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_item.edit',
                'name' => 'Customer Sale Item Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_sale_item',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'saleId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_payment.list',
                'name' => 'Customer Payment List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'customer_payment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_payment.new',
                'name' => 'Customer Payment New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_payment',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_payment.view',
                'name' => 'Customer Payment View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'customer_payment',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_payment.edit',
                'name' => 'Customer Payment Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_payment',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_return.list',
                'name' => 'Customer Return List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'customer_sale_return',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_return.new',
                'name' => 'Customer Return New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_sale_return',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_return.view',
                'name' => 'Customer Return View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'customer_sale_return',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.customer_sale_return.edit',
                'name' => 'Customer Return Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'customer_sale_return',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.delivery_proof.list',
                'name' => 'Delivery Proof List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'delivery_proof',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.delivery_proof.new',
                'name' => 'Delivery Proof New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'delivery_proof',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.delivery_proof.view',
                'name' => 'Delivery Proof View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'delivery_proof',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.delivery_proof.edit',
                'name' => 'Delivery Proof Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'delivery_proof',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_sales',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.sales.dashboard',
                'name' => 'Sales Overview',
                'mode' => 'open_layout',
                'layoutCode' => 'sales',
                'targetRecordTypeCode' => 'customer_sales',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
