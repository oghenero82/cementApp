<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementProcurementRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.purchase.list',
                'name' => 'Supplier Purchase List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'purchase',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseDate',
                        'supplierPin',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase.new',
                'name' => 'Supplier Purchase New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'purchase',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseDate',
                        'supplierPin',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase.view',
                'name' => 'Supplier Purchase View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'purchase',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseDate',
                        'supplierPin',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase.edit',
                'name' => 'Supplier Purchase Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'purchase',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'supplierId',
                        'purchaseDate',
                        'supplierPin',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchaseItem.list',
                'name' => 'Purchase Item List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'purchaseItem',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'purchaseId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchaseItem.new',
                'name' => 'Purchase Item New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'purchaseItem',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchaseItem.view',
                'name' => 'Purchase Item View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'purchaseItem',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchaseItem.edit',
                'name' => 'Purchase Item Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'purchaseItem',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseId',
                        'productId',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_loading.list',
                'name' => 'Cement Loading List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'cement_loading',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                        'supplierDepotId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_loading.new',
                'name' => 'Cement Loading New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'cement_loading',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                        'supplierDepotId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_loading.view',
                'name' => 'Cement Loading View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'cement_loading',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                        'supplierDepotId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.cement_loading.edit',
                'name' => 'Cement Loading Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'cement_loading',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                        'supplierDepotId',
                        'status',
                    ],
                ],
            ],
            [
                'code' => 'cement.loading_clearance.list',
                'name' => 'Loading Clearance List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'loading_clearance',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                    ],
                ],
            ],
            [
                'code' => 'cement.loading_clearance.new',
                'name' => 'Loading Clearance New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'loading_clearance',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                    ],
                ],
            ],
            [
                'code' => 'cement.loading_clearance.view',
                'name' => 'Loading Clearance View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'loading_clearance',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                    ],
                ],
            ],
            [
                'code' => 'cement.loading_clearance.edit',
                'name' => 'Loading Clearance Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'loading_clearance',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'purchaseItemId',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_purchase_payment.list',
                'name' => 'Supplier Payment List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'supplier_purchase_payment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_purchase_payment.new',
                'name' => 'Supplier Payment New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_purchase_payment',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_purchase_payment.view',
                'name' => 'Supplier Payment View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'supplier_purchase_payment',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.supplier_purchase_payment.edit',
                'name' => 'Supplier Payment Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'supplier_purchase_payment',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase_adjustment.list',
                'name' => 'Purchase Adjustment List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'purchase_adjustment',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase_adjustment.new',
                'name' => 'Purchase Adjustment New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'purchase_adjustment',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase_adjustment.view',
                'name' => 'Purchase Adjustment View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'purchase_adjustment',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.purchase_adjustment.edit',
                'name' => 'Purchase Adjustment Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'purchase_adjustment',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_procurement',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                    ],
                ],
            ],
            [
                'code' => 'cement.procurement.dashboard',
                'name' => 'Procurement Overview',
                'mode' => 'open_layout',
                'layoutCode' => 'procurement',
                'targetRecordTypeCode' => 'purchase',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'module' => 'cement_admin',
                ],
            ],
        ];
    }
}
