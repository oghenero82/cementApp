<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Routes;

use App\Database\Seeds\Cement\Support\AbstractRouteSeeder;

final class CementPricingRoutesSeeder extends AbstractRouteSeeder
{
    public static function routes(): array
    {
        return [
            [
                'code' => 'cement.price_list.list',
                'name' => 'Price List List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'price_list',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'priceType',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list.new',
                'name' => 'Price List New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'price_list',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'priceType',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list.view',
                'name' => 'Price List View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'price_list',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'priceType',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list.edit',
                'name' => 'Price List Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'price_list',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'priceType',
                        'customerId',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list_item.list',
                'name' => 'Price List Item List',
                'mode' => 'open_layout',
                'layoutCode' => 'collection',
                'targetRecordTypeCode' => 'price_list_item',
                'operation' => null,
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => true,
                    'displayFields' => [
                        'code',
                        'priceListId',
                        'productId',
                        'unitId',
                        'minQuantity',
                        'validFrom',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list_item.new',
                'name' => 'Price List Item New',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'price_list_item',
                'operation' => 'insert',
                'parameters' => [],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'priceListId',
                        'productId',
                        'unitId',
                        'minQuantity',
                        'validFrom',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list_item.view',
                'name' => 'Price List Item View',
                'mode' => 'open_layout',
                'layoutCode' => 'record_view',
                'targetRecordTypeCode' => 'price_list_item',
                'operation' => null,
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'priceListId',
                        'productId',
                        'unitId',
                        'minQuantity',
                        'validFrom',
                    ],
                ],
            ],
            [
                'code' => 'cement.price_list_item.edit',
                'name' => 'Price List Item Edit',
                'mode' => 'open_layout',
                'layoutCode' => 'record_form',
                'targetRecordTypeCode' => 'price_list_item',
                'operation' => 'update',
                'parameters' => [
                    [
                        'name' => 'recordId',
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'settings' => [
                    'recordIdParameter' => 'recordId',
                    'module' => 'cement_pricing',
                    'allowFilters' => false,
                    'displayFields' => [
                        'code',
                        'priceListId',
                        'productId',
                        'unitId',
                        'minQuantity',
                        'validFrom',
                    ],
                ],
            ],
        ];
    }
}
