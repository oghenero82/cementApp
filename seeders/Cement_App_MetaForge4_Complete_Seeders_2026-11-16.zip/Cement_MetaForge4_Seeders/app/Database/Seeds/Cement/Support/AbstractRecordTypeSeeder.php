<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Support;

use App\Database\Seeds\Cement\CementAppSeeder;
use CodeIgniter\Database\Seeder;

/** Run the master dependency-safe seeder; this class owns an individual declaration. */
abstract class AbstractRecordTypeSeeder extends Seeder
{
    abstract public static function specification(): array;

    public function run()
    {
        (new CementAppSeeder())->run();
    }
}
