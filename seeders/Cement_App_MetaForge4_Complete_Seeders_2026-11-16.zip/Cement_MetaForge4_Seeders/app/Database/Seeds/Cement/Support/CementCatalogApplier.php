<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Support;

use App\Database\Seeds\Cement\CementCatalog;
use App\Database\Seeds\Cement\CementSeedConfig;
use CodeIgniter\Database\BaseConnection;
use Config\Database;
use RuntimeException;
use Throwable;

/**
 * Bootstrap-only catalog installer. Institution transactions still MUST use the
 * authorized MetaForge Mutation API; this class never inserts tenant records.
 *
 * INSERT-only, global-code uniqueness, database-assigned IDs, transactional.
 * Existing editor-customized catalog records are not overwritten.
 */
final class CementCatalogApplier
{
    private BaseConnection $db;
    private array $columns = [];
    private string $idColumn = 'recordId';
    private string $typeColumn = 'recordType';
    private string $codeColumn = 'search1';
    private string $dataColumn = 'jsonData';
    /** @var array<string,int> */
    private array $ids = [];
    /** @var array<string,bool> */
    private array $created = [];
    private array $warnings = [];
    private int $inserted = 0;
    private int $reused = 0;

    public function __construct(?BaseConnection $db = null)
    {
        $this->db = $db ?? Database::connect();
    }

    /** @return array<string,mixed> */
    public function run(): array
    {
        $this->preflight();
        if (CementSeedConfig::dryRun()) {
            return [
                'dryRun' => true,
                'recordTypes' => count(CementCatalog::recordTypes()),
                'modules' => count(CementCatalog::modules()),
                'routes' => count(CementCatalog::routes()),
                'portals' => count(CementCatalog::portals()),
                'serviceRegistrations' => count(CementCatalog::serviceRegistrations()),
                'warning' => 'Dry run does not insert rows.',
            ];
        }

        // Data catalog must be installed after MetaForge's system bootstrap.
        // No CREATE TABLE is executed here; institution tables are provisioned separately.
        $this->db->transBegin();
        try {
            $roots = [
                'record_type' => $this->rootId('record_type'),
                'route' => $this->rootId('route'),
                'portal' => $this->rootId('portal'),
            ];
            $moduleTypeId = $this->rootTypeId('module');
            $physicalTypeId = $this->rootTypeId('physical_table');
            $tableCode = CementSeedConfig::physicalTableCode();
            if ($tableCode === '') {
                throw new RuntimeException('Set CEMENT_RECORD_PHYSICAL_TABLE_CODE to the existing institution-scoped physical_table code. Never fall back to mf_system.');
            }
            $tableId = $this->findTypedId($tableCode, $physicalTypeId);
            if ($tableId === null) {
                throw new RuntimeException("Missing physical_table {$tableCode}; create or provision the proper institution data table before seeding.");
            }
            $this->assertCanonicalRecordTypeSchema($roots['record_type']);
            $this->assertRootSchema('route', ['mode', 'layoutcode', 'recordTypeId', 'portalId', 'parameters', 'settings']);
            $this->assertRootSchema('portal', ['moduleIds', 'routes', 'navigation', 'settings']);

            // 1. Install module records before application RecordTypes.
            $moduleIds = [];
            foreach (CementCatalog::modules() as $code => $data) {
                $moduleIds[$code] = $this->ensure($code, $moduleTypeId, $data + ['status' => 1]);
            }

            // 2. Reserve every RecordType ID before resolving any references.
            $typeIds = [];
            foreach (CementCatalog::recordTypes() as $code => $spec) {
                $typeIds[$code] = $this->ensure($code, $roots['record_type'], [
                    'code' => $code,
                    'name' => $spec['name'],
                    'description' => $spec['description'],
                    'status' => 1,
                    'moduleid' => $moduleIds[$spec['module']],
                    'ptableId' => $tableId,
                    'isSync' => true,
                    'fields' => [],
                ]);
            }
            foreach (['account', 'account_type', 'journal', 'journal_line', 'bank_account', 'member', 'member_account'] as $external) {
                $id = $this->findTypedId($external, $roots['record_type']);
                if ($id !== null) {
                    $typeIds[$external] = $id;
                } elseif (in_array($external, ['account', 'journal', 'bank_account'], true)) {
                    $this->warnings[] = "Missing accounting RecordType: {$external}. Install Accounting before activating posting services.";
                }
            }
            $bindings = getenv('CEMENT_BIND_SERVICE_SUBSCRIPTIONS') === '1';
            if ($bindings) {
                $this->requireHandlers(CementCatalog::serviceRegistrations());
            }
            foreach (CementCatalog::recordTypes() as $code => $spec) {
                if (isset($this->created[$code])) {
                    $data = CementMetadataBuilder::recordType($spec, $moduleIds[$spec['module']], $tableId, $typeIds, $bindings);
                    $this->updateNew($code, $data);
                } else {
                    $this->checkExistingRecordType($code, $spec);
                }
            }

            // 3. Reserve portal IDs for routes targeting the portal (exclusive target).
            $portalIds = [];
            foreach (CementCatalog::portals() as $p) {
                $portalIds[$p['code']] = $this->ensure($p['code'], $roots['portal'], [
                    'code' => $p['code'], 'name' => $p['name'], 'status' => 1,
                    'moduleIds' => [], 'routes' => [], 'navigation' => [],
                ]);
            }

            // 4. Routes contain actual numeric RecordType OR Portal IDs, never both.
            $routeIds = [];
            foreach (CementCatalog::routes() as $route) {
                $payload = $this->routePayload($route, $typeIds, $portalIds);
                $routeIds[$route['code']] = $this->ensure($route['code'], $roots['route'], $payload);
            }
            // 5. Finish new portal records, with numeric Route/Module IDs.
            foreach (CementCatalog::portals() as $portal) {
                if (!isset($this->created[$portal['code']])) {
                    continue;
                }
                $payload = [
                    'code' => $portal['code'],
                    'name' => $portal['name'],
                    'description' => $portal['name'] . ' with server-authorized routes',
                    'status' => 1,
                    'moduleIds' => array_map(static fn(string $v): int => $moduleIds[$v], $portal['modules']),
                    'routes' => array_values(array_map(static fn(string $v): int => $routeIds[$v], $portal['routes'])),
                    'navigation' => $this->navigation($portal['navigation'], $routeIds),
                    'settings' => $portal['settings'] + ['dashboardRouteId' => $routeIds[$portal['settings']['defaultRoute']]],
                ];
                $this->updateNew($portal['code'], $payload);
            }

            // Service metadata records are optional: MetaForge may use a code registry
            // instead of a RecordType. Do not assume a table/handler exists.
            if (CementSeedConfig::seedServiceRecords()) {
                $registryCode = CementSeedConfig::serviceRegistryCode();
                if ($registryCode === '') {
                    throw new RuntimeException('CEMENT_SERVICE_RECORDTYPE_CODE is required when CEMENT_SEED_SERVICE_RECORDS=1.');
                }
                $typeId = $this->findTypedId($registryCode, $roots['record_type']);
                if ($typeId === null) {
                    throw new RuntimeException("Service registry RecordType '{$registryCode}' not found; configure a registered service catalog instead.");
                }
                foreach (CementCatalog::serviceRegistrations() as $code => $s) {
                    $this->ensure('cement_service.' . $code, $typeId, [
                        'code' => 'cement_service.' . $code,
                        'name' => $s['name'], 'description' => $s['description'],
                        'service' => $s['code'], 'handlerClass' => $s['handlerClass'],
                        'method' => $s['method'], 'stage' => $s['stages'][0],
                        'status' => 0, // Pending activation and validation of actual handler.
                    ]);
                }
            }
            if ($this->db->transStatus() === false) {
                throw new RuntimeException('Database transaction failed while seeding Cement catalog.');
            }
            if (!$this->db->transCommit()) {
                throw new RuntimeException('Commit failed while seeding Cement catalog.');
            }
            return [
                'inserted' => $this->inserted,
                'reused' => $this->reused,
                'recordTypes' => count(CementCatalog::recordTypes()),
                'modules' => count(CementCatalog::modules()),
                'routes' => count(CementCatalog::routes()),
                'portals' => count(CementCatalog::portals()),
                'serviceRegistrations' => count(CementCatalog::serviceRegistrations()),
                'bindingsEnabled' => $bindings,
                'warnings' => $this->warnings,
                'next' => 'Rebuild the MetaForge SystemCatalog after commit; assign portals/routes through actual role permissions.',
            ];
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }

    private function preflight(): void
    {
        if (!$this->db->tableExists(CementSeedConfig::TABLE_SYSTEM)) {
            throw new RuntimeException('Missing mf_system. Run the MetaForge 4 core bootstrap first.');
        }
        $this->columns = $this->db->getFieldNames(CementSeedConfig::TABLE_SYSTEM);
        $this->idColumn = $this->column(['recordId', 'id']);
        $this->typeColumn = $this->column(['recordType', 'recordTypeId']);
        $this->codeColumn = $this->column(['search1', 'recordCode']);
        $this->dataColumn = $this->column(['jsonData']);
    }

    private function column(array $choices): string
    {
        foreach ($choices as $candidate) {
            if (in_array($candidate, $this->columns, true)) {
                return $candidate;
            }
        }
        throw new RuntimeException('Incompatible mf_system table: expected one of ' . implode(', ', $choices));
    }

    private function rootId(string $code): int
    {
        $id = $this->findTypedId($code, 0);
        if ($id === null) {
            throw new RuntimeException("MetaForge root definition '{$code}' is missing. Run system starter bootstrap first.");
        }
        return $id;
    }

    /** Resolve a RecordType, e.g. "module", as an instance of root record_type. */
    private function rootTypeId(string $code): int
    {
        $id = $this->findTypedId($code, $this->rootId('record_type'));
        if ($id === null) {
            throw new RuntimeException("MetaForge RecordType '{$code}' is missing.");
        }
        return $id;
    }

    private function findTypedId(string $code, int $expectedType): ?int
    {
        $row = $this->find($code);
        if ($row === null) {
            return null;
        }
        $this->verify($row, $code, $expectedType);
        return (int)$row[$this->idColumn];
    }

    /** @return array<string,mixed>|null */
    private function find(string $code): ?array
    {
        $rows = $this->db->table(CementSeedConfig::TABLE_SYSTEM)
            ->where($this->codeColumn, $code)->limit(2)->get()->getResultArray();
        if (count($rows) > 1) {
            throw new RuntimeException('Duplicate global MetaForge code: ' . $code);
        }
        return $rows[0] ?? null;
    }

    private function decode(array $row): array
    {
        $raw = $row[$this->dataColumn] ?? null;
        $data = is_array($raw) ? $raw : json_decode((string)$raw, true);
        if (!is_array($data)) {
            throw new RuntimeException('Malformed jsonData for system ID ' . $row[$this->idColumn]);
        }
        return $data;
    }

    private function verify(array $row, string $code, int $typeId): void
    {
        if ((int)$row[$this->typeColumn] !== $typeId) {
            throw new RuntimeException("Catalog code '{$code}' exists under a DIFFERENT RecordType. Refusing overwrite.");
        }
        foreach (['deleted', 'isDeleted'] as $deletedCol) {
            if (array_key_exists($deletedCol, $row) && (int)$row[$deletedCol] !== 0) {
                throw new RuntimeException("Catalog code '{$code}' is soft-deleted; recover explicitly.");
            }
        }
        if (isset($row['deletedAt']) && $row['deletedAt'] !== null) {
            throw new RuntimeException("Catalog code '{$code}' was deleted; recover explicitly.");
        }
        $data = $this->decode($row);
        if (($data['code'] ?? null) !== $code) {
            throw new RuntimeException("search1/jsonData.code mismatch for '{$code}'.");
        }
    }

    private function ensure(string $code, int $typeId, array $data): int
    {
        if ($code === '' || ($data['code'] ?? null) !== $code) {
            throw new RuntimeException('Invalid catalog identity: ' . $code);
        }
        if ($existing = $this->find($code)) {
            $this->verify($existing, $code, $typeId);
            ++$this->reused;
            return $this->ids[$code] = (int)$existing[$this->idColumn];
        }
        $payload = [
            $this->typeColumn => $typeId,
            $this->codeColumn => $code,
            $this->dataColumn => json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ];
        foreach (['createdAt', 'created_at', 'updatedAt', 'updated_at'] as $timestampCol) {
            if (in_array($timestampCol, $this->columns, true)) {
                $payload[$timestampCol] = gmdate('Y-m-d H:i:s');
            }
        }
        if (!$this->db->table(CementSeedConfig::TABLE_SYSTEM)->insert($payload)) {
            throw new RuntimeException('Could not insert catalog metadata for ' . $code);
        }
        $id = (int)$this->db->insertID();
        if ($id < 1) {
            throw new RuntimeException('Database failed to assign ID to ' . $code);
        }
        $this->created[$code] = true;
        ++$this->inserted;
        return $this->ids[$code] = $id;
    }

    private function updateNew(string $code, array $data): void
    {
        if (!isset($this->created[$code])) {
            throw new RuntimeException('Refusing overwrite of an existing catalog record: ' . $code);
        }
        $payload = [$this->dataColumn => json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];
        foreach (['updatedAt', 'updated_at'] as $timestampCol) {
            if (in_array($timestampCol, $this->columns, true)) {
                $payload[$timestampCol] = gmdate('Y-m-d H:i:s');
            }
        }
        $ok = $this->db->table(CementSeedConfig::TABLE_SYSTEM)
            ->where($this->idColumn, $this->ids[$code])->update($payload);
        if (!$ok) {
            throw new RuntimeException('Failed to finalize new catalog record: ' . $code);
        }
    }

    private function assertCanonicalRecordTypeSchema(int $rootId): void
    {
        $row = $this->find('record_type');
        $data = $this->decode($row ?? []);
        $actual = [];
        foreach (($data['fields'] ?? []) as $f) {
            if (is_array($f) && is_string($f['code'] ?? null)) {
                $actual[] = $f['code'];
            }
        }
        // Some deployments have not yet applied the post-2026-11-13 schema.
        // Reject rather than silently lose uniqueness/validation/related actions.
        $required = ['fields', 'services', 'relatedActions', 'validation', 'lookups',
            'searchColumnsMapping', 'uniques', 'lifecycle', 'ptableId', 'moduleid'];
        $missing = array_values(array_diff($required, $actual));
        if ($missing !== []) {
            throw new RuntimeException(
                'This package requires the locked MetaForge 4 RecordType schema (2026-11-14). '
                . 'Schema currently lacks: ' . implode(', ', $missing)
                . '. Upgrade the root definition and metadata engines first; this seeder never silently drops features.'
            );
        }
    }

    /** Guard against direct-inserting invalid Route or Portal metadata. */
    private function assertRootSchema(string $code, array $required): void
    {
        $row = $this->find($code);
        if ($row === null) {
            throw new RuntimeException('Missing root schema: ' . $code);
        }
        $data = $this->decode($row);
        $actual = [];
        foreach (($data['fields'] ?? []) as $f) {
            if (is_array($f) && is_string($f['code'] ?? null)) {
                $actual[] = $f['code'];
            }
        }
        $missing = array_values(array_diff($required, $actual));
        if ($missing !== []) {
            throw new RuntimeException(
                "Outdated '{$code}' root schema: " . implode(', ', $missing)
                . '. Upgrade it before running CementAppSeeder.'
            );
        }
    }

    private function checkExistingRecordType(string $code, array $spec): void
    {
        $row = $this->find($code);
        $old = $this->decode($row ?? []);
        $actual = [];
        foreach (($old['fields'] ?? []) as $f) {
            if (is_array($f) && is_string($f['code'] ?? null)) {
                $actual[] = $f['code'];
            }
        }
        $declared = array_column($spec['fields'], 'code');
        $missing = array_values(array_diff($declared, $actual));
        if ($missing !== []) {
            $msg = "Existing RecordType '{$code}' lacks declared fields: " . implode(', ', $missing);
            if (CementSeedConfig::strict()) {
                throw new RuntimeException($msg . '. Use an explicit authorized migration.');
            }
            $this->warnings[] = $msg . ' (unchanged; review with RecordType editor).';
        }
    }

    private function routePayload(array $r, array $typeIds, array $portalIds): array
    {
        $code = $r['code'];
        $targetCode = $r['targetRecordTypeCode'] ?? null;
        $payload = [
            'code' => $code,
            'name' => $r['name'],
            'description' => 'Cement frontend route: ' . $r['name'],
            'status' => 1,
            'mode' => 'open_layout',
            'layoutcode' => $r['layoutCode'],
            'parameters' => $r['parameters'],
            'settings' => $r['settings'],
        ];
        if ($targetCode !== null) {
            if (!isset($typeIds[$targetCode])) {
                throw new RuntimeException('Route references missing RecordType: ' . $targetCode);
            }
            $payload['recordTypeId'] = $typeIds[$targetCode];
            if ($r['operation'] !== null) {
                $payload['operation'] = $r['operation'];
            }
        } else {
            // Portal-targeted routes have no RecordType. All authorized
            // portals may link to an explicit portal route; role still filters.
            $primary = $r['targetPortalCode'] ?? 'cement_admin_portal';
            if (!isset($portalIds[$primary])) {
                throw new RuntimeException('Dashboard primary portal missing.');
            }
            $payload['portalId'] = $portalIds[$primary];
        }
        if (isset($payload['recordTypeId']) === isset($payload['portalId'])) {
            throw new RuntimeException('Route must target exactly one RecordType OR Portal.');
        }
        return $payload;
    }

    private function navigation(array $items, array $routeIds): array
    {
        $out = [];
        foreach ($items as $item) {
            $dest = [
                'code' => $item['code'],
                'label' => $item['label'],
                'icon' => $item['icon'],
                'issection' => (bool)$item['issection'],
                'visible' => (bool)$item['visible'],
                'position' => (int)$item['position'],
            ];
            if (isset($item['routeCode'])) {
                if (!isset($routeIds[$item['routeCode']])) {
                    throw new RuntimeException('Navigation route not seeded: ' . $item['routeCode']);
                }
                $dest['routeid'] = $routeIds[$item['routeCode']];
                $dest['paras'] = [];
            }
            if (isset($item['children'])) {
                $dest['sectionchildren'] = $this->navigation($item['children'], $routeIds);
            }
            $out[] = $dest;
        }
        return $out;
    }

    private function requireHandlers(array $serviceDefinitions): void
    {
        $missing=[];
        foreach ($serviceDefinitions as $s) {
            if (!class_exists($s['handlerClass']) || !method_exists($s['handlerClass'], $s['method'])) {
                $missing[]=$s['handlerClass'].'::'.$s['method'];
            } else {
                $method = new \ReflectionMethod($s['handlerClass'], $s['method']);
                if (!$method->isPublic()) $missing[]=$s['handlerClass'].'::'.$s['method'].' (not public)';
            }
        }
        if ($missing !== []) {
            throw new RuntimeException(
                'Cannot enable service subscriptions until trusted handlers are implemented: '
                . implode(', ', $missing)
            );
        }
    }
}
