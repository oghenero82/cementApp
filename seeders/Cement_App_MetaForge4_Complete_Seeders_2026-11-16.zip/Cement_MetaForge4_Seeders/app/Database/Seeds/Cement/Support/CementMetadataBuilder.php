<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Support;

use RuntimeException;

final class CementMetadataBuilder
{
    /** @var array<string,list<string>> */
    private const READ_ONLY = [
        'purchaseItem' => [
            'loadedQty',
            'clearedQty',
            'deliveredQty',
            'fullyDelivered',
            'firstLoadedAt',
        ],
        'inventory_stock' => [
            'quantityOnHand',
            'quantityReserved',
            'quantityAvailable',
            'averageUnitCost',
            'totalValue',
            'lastMovementAt',
        ],
        'inventory_cost_layer' => [
            'remainingQty',
        ],
        'customer_sales' => [
            'grossAmount',
            'discountAmount',
            'taxAmount',
            'netAmount',
            'amountPaid',
            'balanceDue',
        ],
        'trip' => [
            'totalFuelCost',
            'totalMaintenanceCost',
            'totalTripExpense',
            'totalTripCost',
        ],
        'inventory_stocktake_line' => [
            'systemQty',
            'varianceQty',
            'varianceValue',
        ],
    ];
    private const DEFAULT_STATUS = [
        'purchase' => 'draft',
        'purchaseItem' => 'open',
        'cement_loading' => 'draft',
        'loading_clearance' => 'draft',
        'customer_sales' => 'draft',
        'customer_sale_item' => 'open',
        'customer_payment' => 'draft',
        'inventory_movement' => 'draft',
        'inventory_stocktake' => 'draft',
        'stock_adjustment' => 'draft',
        'inventory_transfer' => 'draft',
        'customer_sale_return' => 'draft',
        'trip' => 'planned',
        'payroll' => 'draft',
        'payroll_payment' => 'draft',
        'supplier_incentive' => 'pending',
        'expense' => 'draft',
    ];
    private const INDEXES = [
        'person' => [
            'code',
            'phone',
            'email',
        ],
        'customer' => [
            'code',
            'companyName',
            'phone',
        ],
        'supplier' => [
            'code',
            'name',
            'supplierNumber',
        ],
        'supplier_depot' => [
            'code',
            'supplierId',
            'supplierDepotCode',
        ],
        'supplier_product' => [
            'code',
            'supplierId',
            'productId',
        ],
        'unit_of_measure' => [
            'code',
            'symbol',
        ],
        'product_category' => [
            'code',
            'name',
        ],
        'product' => [
            'code',
            'name',
            'categoryId',
        ],
        'price_list' => [
            'code',
            'priceType',
            'customerId',
        ],
        'price_list_item' => [
            'code',
            'priceListId',
            'productId',
            'unitId',
            'minQuantity',
            'validFrom',
        ],
        'purchase' => [
            'code',
            'supplierId',
            'purchaseDate',
            'supplierPin',
        ],
        'purchaseItem' => [
            'code',
            'purchaseId',
            'productId',
        ],
        'cement_loading' => [
            'code',
            'purchaseItemId',
            'supplierDepotId',
            'status',
        ],
        'loading_clearance' => [
            'code',
            'purchaseItemId',
        ],
        'supplier_purchase_payment' => [
            'code',
        ],
        'purchase_adjustment' => [
            'code',
        ],
        'customer_sales' => [
            'code',
            'customerId',
            'saleDate',
            'status',
        ],
        'customer_sale_item' => [
            'code',
            'saleId',
            'productId',
        ],
        'customer_payment' => [
            'code',
        ],
        'customer_sale_return' => [
            'code',
        ],
        'delivery_proof' => [
            'code',
        ],
        'inventory_location' => [
            'code',
        ],
        'inventory_stock' => [
            'code',
            'locationId',
            'productId',
            'stockCondition',
        ],
        'inventory_movement' => [
            'code',
            'productId',
            'sourceRecordId',
            'status',
        ],
        'inventory_cost_layer' => [
            'code',
            'stockId',
            'sourceMovementId',
        ],
        'inventory_stocktake' => [
            'code',
            'locationId',
            'countDate',
        ],
        'inventory_stocktake_line' => [
            'code',
            'stocktakeId',
            'productId',
        ],
        'stock_adjustment' => [
            'code',
            'locationId',
            'productId',
            'status',
        ],
        'damaged_goods' => [
            'code',
        ],
        'inventory_transfer' => [
            'code',
        ],
        'vehicle' => [
            'code',
            'registrationNumber',
        ],
        'trip' => [
            'code',
            'vehicleId',
            'driverId',
            'status',
        ],
        'trip_destination' => [
            'code',
            'tripId',
            'customerId',
        ],
        'fuel_transaction' => [
            'code',
        ],
        'vehicle_maintenance' => [
            'code',
        ],
        'trip_expense' => [
            'code',
        ],
        'supplier_incentive_scheme' => [
            'code',
        ],
        'supplier_incentive' => [
            'code',
            'supplierId',
            'purchaseId',
        ],
        'supplier_incentive_receipt' => [
            'code',
        ],
        'staff_employment' => [
            'code',
            'personId',
            'employeeNumber',
        ],
        'payroll' => [
            'code',
            'periodStart',
        ],
        'payroll_item' => [
            'code',
            'payrollId',
            'employmentId',
        ],
        'payroll_payment' => [
            'code',
        ],
        'staff_deduction' => [
            'code',
        ],
        'expense' => [
            'code',
            'tripId',
            'expenseDate',
        ],
        'report' => [
            'code',
            'generationMode',
        ],
        'report_result' => [
            'code',
            'reportId',
            'generatedAt',
        ],
        'report_delivery' => [
            'code',
        ],
        'report_schedule' => [
            'code',
        ],
        'cement_branch' => [
            'code',
        ],
        'cement_audit_event' => [
            'code',
        ],
    ];
    private const UNIQUE_GROUPS = [
        'person' => [
            [
                'code',
            ],
        ],
        'customer' => [
            [
                'code',
            ],
        ],
        'supplier' => [
            [
                'code',
            ],
        ],
        'supplier_depot' => [
            [
                'code',
            ],
            [
                'supplierId',
                'supplierDepotCode',
            ],
        ],
        'supplier_product' => [
            [
                'code',
            ],
            [
                'supplierId',
                'productId',
            ],
        ],
        'unit_of_measure' => [
            [
                'code',
            ],
            [
                'symbol',
            ],
        ],
        'product_category' => [
            [
                'code',
            ],
        ],
        'product' => [
            [
                'code',
            ],
        ],
        'price_list' => [
            [
                'code',
            ],
        ],
        'price_list_item' => [
            [
                'code',
            ],
            [
                'priceListId',
                'productId',
                'unitId',
                'minQuantity',
                'validFrom',
            ],
        ],
        'purchase' => [
            [
                'code',
            ],
        ],
        'purchaseItem' => [
            [
                'code',
            ],
        ],
        'cement_loading' => [
            [
                'code',
            ],
        ],
        'loading_clearance' => [
            [
                'code',
            ],
        ],
        'supplier_purchase_payment' => [
            [
                'code',
            ],
        ],
        'purchase_adjustment' => [
            [
                'code',
            ],
        ],
        'customer_sales' => [
            [
                'code',
            ],
        ],
        'customer_sale_item' => [
            [
                'code',
            ],
        ],
        'customer_payment' => [
            [
                'code',
            ],
        ],
        'customer_sale_return' => [
            [
                'code',
            ],
        ],
        'delivery_proof' => [
            [
                'code',
            ],
        ],
        'inventory_location' => [
            [
                'code',
            ],
        ],
        'inventory_stock' => [
            [
                'code',
            ],
            [
                'locationId',
                'productId',
                'stockCondition',
            ],
        ],
        'inventory_movement' => [
            [
                'code',
            ],
        ],
        'inventory_cost_layer' => [
            [
                'code',
            ],
        ],
        'inventory_stocktake' => [
            [
                'code',
            ],
        ],
        'inventory_stocktake_line' => [
            [
                'code',
            ],
        ],
        'stock_adjustment' => [
            [
                'code',
            ],
        ],
        'damaged_goods' => [
            [
                'code',
            ],
        ],
        'inventory_transfer' => [
            [
                'code',
            ],
        ],
        'vehicle' => [
            [
                'code',
            ],
            [
                'registrationNumber',
            ],
        ],
        'trip' => [
            [
                'code',
            ],
        ],
        'trip_destination' => [
            [
                'code',
            ],
        ],
        'fuel_transaction' => [
            [
                'code',
            ],
        ],
        'vehicle_maintenance' => [
            [
                'code',
            ],
        ],
        'trip_expense' => [
            [
                'code',
            ],
        ],
        'supplier_incentive_scheme' => [
            [
                'code',
            ],
        ],
        'supplier_incentive' => [
            [
                'code',
            ],
        ],
        'supplier_incentive_receipt' => [
            [
                'code',
            ],
        ],
        'staff_employment' => [
            [
                'code',
            ],
            [
                'employeeNumber',
            ],
        ],
        'payroll' => [
            [
                'code',
            ],
        ],
        'payroll_item' => [
            [
                'code',
            ],
        ],
        'payroll_payment' => [
            [
                'code',
            ],
        ],
        'staff_deduction' => [
            [
                'code',
            ],
        ],
        'expense' => [
            [
                'code',
            ],
        ],
        'report' => [
            [
                'code',
            ],
        ],
        'report_result' => [
            [
                'code',
            ],
        ],
        'report_delivery' => [
            [
                'code',
            ],
        ],
        'report_schedule' => [
            [
                'code',
            ],
        ],
        'cement_branch' => [
            [
                'code',
            ],
        ],
        'cement_audit_event' => [
            [
                'code',
            ],
        ],
    ];

    /** @param array<string,int> $typeIds */
    public static function recordType(array $spec, int $moduleId, int $tableId, array $typeIds, bool $bindServices = false): array
    {
        $code=$spec['code'];
        $fields=[];
        foreach ($spec['fields'] as $descriptor) {
            $fields[]=self::field($descriptor,$typeIds,$code);
        }
        $search=[];
        foreach (self::INDEXES[$code] as $idx=>$fieldCode) {
            $search[$fieldCode]='search'.($idx+1);
        }
        $uniques=[];
        foreach (self::UNIQUE_GROUPS[$code] as $idx=>$fieldCodes) {
            $uniques[]=['code'=>'unique_'.($idx+1),'fields'=>$fieldCodes];
        }
        $result=[
            'code'=>$code,'name'=>$spec['name'],'description'=>$spec['description'],
            'status'=>1,'ptableId'=>$tableId,'moduleid'=>$moduleId,'isSync'=>true,
            'actions'=>['insert','update','delete'],
            'fields'=>$fields,'validation'=>self::validations($code),
            'relatedActions'=>$bindServices ? self::relatedActions($code,$typeIds) : [],
            'services'=>$bindServices ? self::subscriptions($spec) : [],
            'searchColumnsMapping'=>$search,'uniques'=>$uniques,
            'lookups'=>self::lookups($code,$spec),
            'lifecycle'=>self::lifecycle($spec),
        ];
        return $result;
    }

    private const DEFAULTS=[
        'purchaseItem' => [
            'loadedQty' => 0,
            'clearedQty' => 0,
            'deliveredQty' => 0,
            'fullyDelivered' => false,
        ],
        'inventory_stock' => [
            'quantityOnHand' => 0,
            'quantityReserved' => 0,
            'quantityAvailable' => 0,
            'averageUnitCost' => 0,
            'totalValue' => 0,
        ],
        'inventory_cost_layer' => [
            'remainingQty' => 0,
        ],
        'customer_sales' => [
            'grossAmount' => 0,
            'discountAmount' => 0,
            'taxAmount' => 0,
            'netAmount' => 0,
            'amountPaid' => 0,
            'balanceDue' => 0,
        ],
        'trip' => [
            'totalQuantity' => 0,
            'totalFuelCost' => 0,
            'totalMaintenanceCost' => 0,
            'totalTripExpense' => 0,
            'totalTripCost' => 0,
        ],
        'inventory_stocktake_line' => [
            'varianceQty' => 0,
            'varianceValue' => 0,
        ],
        'purchase' => [
            'grossAmount' => 0,
            'discountAmount' => 0,
            'netAmount' => 0,
            'paidAmount' => 0,
        ],
        'payroll' => [
            'totalGross' => 0,
            'totalDeductions' => 0,
            'totalNet' => 0,
        ],
        'inventory_movement' => [
            'stockCondition' => 'good',
        ],
    ];

    private static function field(array $d,array $typeIds,string $code): array
    {
        $f=['code'=>$d['code'],'name'=>self::label($d['code']),'type'=>$d['type'],
            'properties'=>['required'=>$d['required'],'persistent'=>true,'readOnly'=>in_array($d['code'],self::READ_ONLY[$code]??[],true)],
            'fproperties'=>['label'=>self::label($d['code']),'showInList'=>in_array($d['code'],self::INDEXES[$code],true)],
        ];
        if ($d['code']==='status') {
            $f['default']=self::DEFAULT_STATUS[$code]??'active';
        } elseif (array_key_exists($d['code'],self::DEFAULTS[$code]??[])) {
            $f['default']=self::DEFAULTS[$code][$d['code']];
        }
        if ($d['type']==='reference') {
            $target=$d['target']??null;
            if ($target===null) throw new RuntimeException('Missing reference target for '.$code.'.'.$d['code']);
            if (isset($typeIds[$target])) $f['recordTypeId']=$typeIds[$target];
            $f['properties']['reference']=['recordTypeCode'=>$target];
        }
        foreach (self::embeddedFields($code,$d['code']) as $key=>$value) $f['properties'][$key]=$value;
        if (isset(self::DERIVED[$code][$d['code']])) $f['derived']=self::DERIVED[$code][$d['code']];
        return $f;
    }

    private static function label(string $code): string
    {
        return ucwords(trim(preg_replace('/([a-z])([A-Z])|_+/','$1 $2',$code)??$code));
    }

    private const DERIVED=[
        'purchaseItem' => [
            'amount' => [
                'expression' => 'originalQuantity * netUnitCost',
                'environment' => 'both',
                'on' => [
                    'insert',
                    'update',
                ],
                'order' => 10,
            ],
        ],
        'customer_sale_item' => [
            'lineAmount' => [
                'expression' => 'quantity * netUnitPrice + taxAmount',
                'environment' => 'both',
                'on' => [
                    'insert',
                    'update',
                ],
                'order' => 10,
            ],
        ],
        'fuel_transaction' => [
            'totalAmount' => [
                'expression' => 'litres * pricePerLitre',
                'environment' => 'both',
                'on' => [
                    'insert',
                    'update',
                ],
                'order' => 10,
            ],
        ],
        'vehicle_maintenance' => [
            'totalCost' => [
                'expression' => 'partsCost + laborCost',
                'environment' => 'both',
                'on' => [
                    'insert',
                    'update',
                ],
                'order' => 10,
            ],
        ],
    ];

    private static function embeddedFields(string $rt,string $code): array
    {
        if ($rt==='cement_loading' && $code==='destinations') {
            return ['items'=>['type'=>'object','fields'=>[
                ['code'=>'destinationType','type'=>'string','properties'=>['required'=>true]],
                ['code'=>'customerId','type'=>'reference'],
                ['code'=>'warehouseLocationId','type'=>'reference'],
                ['code'=>'quantity','type'=>'number','properties'=>['required'=>true]],
                ['code'=>'unitId','type'=>'reference'],
                ['code'=>'tripDestinationId','type'=>'reference'],
            ]]];
        }
        return [];
    }

    private static function validations(string $code): array
    {
        $rules=self::VALIDATIONS[$code]??[];
        $out=[];
        foreach ($rules as $idx=>$entry) $out[]=['code'=>'rule_'.($idx+1),'condition'=>$entry[0],'message'=>$entry[1],'environments'=>['insert','update']];
        return $out;
    }

    private const VALIDATIONS=[
        'purchaseItem' => [
            [
                'originalQuantity > 0',
                'Purchase quantity must be positive',
            ],
            [
                'netUnitCost >= 0',
                'Net unit cost must be non-negative',
            ],
            [
                'loadedQty <= originalQuantity',
                'Cannot load more than purchased',
            ],
            [
                'clearedQty <= loadedQty',
                'Cannot clear beyond loaded quantity',
            ],
        ],
        'cement_loading' => [
            [
                'quantity > 0',
                'Loading quantity must be positive',
            ],
            [
                'customerQuantity + warehouseQuantity == quantity',
                'Customer and warehouse allocations must equal loading quantity',
            ],
        ],
        'loading_clearance' => [
            [
                'quantity > 0',
                'Clearing quantity must be positive',
            ],
        ],
        'customer_sale_item' => [
            [
                'quantity > 0',
                'Sale quantity must be positive',
            ],
            [
                'agreedUnitPrice >= 0',
                'Agreed price must not be negative',
            ],
        ],
        'inventory_movement' => [
            [
                'qtyBase > 0',
                'Movement quantity must be positive',
            ],
        ],
        'inventory_stock' => [
            [
                'quantityOnHand >= 0',
                'No negative stock without an authorized exception',
            ],
        ],
        'inventory_stocktake_line' => [
            [
                'countedQty >= 0',
                'Counted quantity must not be negative',
            ],
        ],
        'stock_adjustment' => [
            [
                'quantityDelta != 0',
                'Adjustment cannot be zero',
            ],
        ],
        'trip_destination' => [
            [
                'quantity > 0',
                'Destination quantity must be positive',
            ],
        ],
        'fuel_transaction' => [
            [
                'litres > 0',
                'Fuel volume must be positive',
            ],
        ],
        'payroll_item' => [
            [
                'netPay >= 0',
                'Payroll net pay must not be negative',
            ],
        ],
    ];

    private static function subscriptions(array $spec): array
    {
        $out=[];
        foreach ($spec['services']??[] as $i=>$x) {
            $out[]=['code'=>$x['code'].'.binding','service'=>$x['code'],'method'=>'execute','stage'=>$x['stage'],'trigger'=>$x['trigger'],'parameters'=>[],'order'=>$i+1];
        }
        return $out;
    }

    private static function lookups(string $code,array $spec): array
    {
        $codes=array_column($spec['fields'],'code');
        $label=in_array('name',$codes,true)?'name':'code';
        return [['code'=>$code.'.by_code','label'=>$label,'valueFieldCode'=>'code']];
    }

    private static function lifecycle(array $spec): array
    {
        $data=$spec['lifecycle']??null;
        if ($data===null) return [];
        $steps=[];
        foreach ($data['states'] as $from) {
            if (in_array($from,$data['terminalStates'],true))continue;
            foreach ($data['states'] as $to) {
                if ($from===$to) continue;
                // No unreviewed jumps: restrict to next state; cancellation is explicit.
                $fromAt=array_search($from,$data['states'],true);
                $toAt=array_search($to,$data['states'],true);
                if ($toAt===$fromAt+1 || in_array($to,['cancelled','rejected'],true)) {
                    $steps[]=['from'=>$from,'to'=>$to,'operation'=>'update','condition'=>true];
                }
            }
        }
        return ['fieldCode'=>$data['fieldCode'],'initialState'=>$data['initialState'],'terminalStates'=>$data['terminalStates'],'transitions'=>$steps];
    }

    private static function relatedActions(string $code,array $typeIds): array
    {
        $rows=self::RELATED[$code]??[];
        foreach ($rows as &$r) {
            $target=$r['targetRecordTypeCode'];unset($r['targetRecordTypeCode']);
            if (!isset($typeIds[$target])) throw new RuntimeException('Missing related RecordType: '.$target);
            $r['targetRecordTypeId']=$typeIds[$target];
        }
        unset($r);
        return $rows;
    }

    private const RELATED=[
        'inventory_movement' => [
            [
                'code' => 'apply_source_stock',
                'executionStage' => 'After_Main_save',
                'operation' => 'update',
                'targetRecordTypeCode' => 'inventory_stock',
                'trigger' => 'status == "confirmed" && sourceLocationId != null',
                'order' => 1,
                'relationship' => 'associated_one',
                'on_missing' => 'create',
                'lookup' => [
                    'locationId' => [
                        'source' => 'data',
                        'key' => 'sourceLocationId',
                    ],
                    'productId' => [
                        'source' => 'data',
                        'key' => 'productId',
                    ],
                    'stockCondition' => [
                        'source' => 'data',
                        'key' => 'stockCondition',
                    ],
                ],
                'fieldMappings' => [
                    'quantityOnHand' => [
                        'source' => 'results',
                        'key' => 'sourceStockNextQty',
                    ],
                    'quantityAvailable' => [
                        'source' => 'results',
                        'key' => 'sourceStockNextAvailable',
                    ],
                    'totalValue' => [
                        'source' => 'results',
                        'key' => 'sourceStockNextValue',
                    ],
                ],
            ],
            [
                'code' => 'apply_destination_stock',
                'executionStage' => 'After_Main_save',
                'operation' => 'update',
                'targetRecordTypeCode' => 'inventory_stock',
                'trigger' => 'status == "confirmed" && destinationLocationId != null',
                'order' => 2,
                'relationship' => 'associated_one',
                'on_missing' => 'create',
                'lookup' => [
                    'locationId' => [
                        'source' => 'data',
                        'key' => 'destinationLocationId',
                    ],
                    'productId' => [
                        'source' => 'data',
                        'key' => 'productId',
                    ],
                    'stockCondition' => [
                        'source' => 'data',
                        'key' => 'stockCondition',
                    ],
                ],
                'fieldMappings' => [
                    'quantityOnHand' => [
                        'source' => 'results',
                        'key' => 'destinationStockNextQty',
                    ],
                    'quantityAvailable' => [
                        'source' => 'results',
                        'key' => 'destinationStockNextAvailable',
                    ],
                    'totalValue' => [
                        'source' => 'results',
                        'key' => 'destinationStockNextValue',
                    ],
                ],
            ],
        ],
        'cement_loading' => [
            [
                'code' => 'issue_customer_sales',
                'executionStage' => 'After_Main_save',
                'operation' => 'insert',
                'targetRecordTypeCode' => 'customer_sales',
                'trigger' => 'status == "confirmed" && customerQuantity > 0',
                'order' => 1,
                'relationship' => 'dependent_many',
                'on_missing' => 'error',
                'fieldMappings' => [
                    'items' => [
                        'source' => 'results',
                        'key' => 'customerSalesRecords',
                    ],
                ],
            ],
            [
                'code' => 'issue_warehouse_receipts',
                'executionStage' => 'After_Main_save',
                'operation' => 'insert',
                'targetRecordTypeCode' => 'inventory_movement',
                'trigger' => 'status == "confirmed" && warehouseQuantity > 0',
                'order' => 2,
                'relationship' => 'dependent_many',
                'on_missing' => 'error',
                'fieldMappings' => [
                    'items' => [
                        'source' => 'results',
                        'key' => 'warehouseMovementRecords',
                    ],
                ],
            ],
        ],
        'delivery_proof' => [
            [
                'code' => 'mark_trip_destination_delivered',
                'executionStage' => 'After_Main_save',
                'operation' => 'update',
                'targetRecordTypeCode' => 'trip_destination',
                'trigger' => 'status == "confirmed" && tripDestinationId != null',
                'targetRecordId' => [
                    'source' => 'data',
                    'key' => 'tripDestinationId',
                ],
                'order' => 1,
                'relationship' => 'associated_one',
                'on_missing' => 'error',
                'fieldMappings' => [
                    'deliveryStatus' => [
                        'source' => 'fixed',
                        'value' => 'delivered',
                    ],
                    'deliveredAt' => [
                        'source' => 'data',
                        'key' => 'deliveredDate',
                    ],
                ],
            ],
        ],
    ];
}
