<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement;

use CodeIgniter\Database\Seeder;
use App\Database\Seeds\Cement\Support\CementCatalogApplier;

/** Master CI4 installation entrypoint, rerunnable and transaction-scoped. */
final class CementAppSeeder extends Seeder
{
    public function run()
    {
        $report=(new CementCatalogApplier($this->db))->run();
        if (function_exists('log_message')) {
            log_message('info', 'Cement seed: {summary}', ['summary' => json_encode($report, JSON_THROW_ON_ERROR)]);
        }
    }
}
