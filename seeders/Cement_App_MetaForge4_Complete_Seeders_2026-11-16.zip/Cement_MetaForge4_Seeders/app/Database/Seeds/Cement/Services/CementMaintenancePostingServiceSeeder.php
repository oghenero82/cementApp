<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementMaintenancePostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementMaintenancePostingService',
            'name' => 'Maintenance Service',
            'description' => 'Post fleet maintenance GL',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementMaintenancePostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'vehicle_maintenance',
            'trigger' => 'status == "posted"',
        ];
    }
}
