<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementPurchaseItemLockServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementPurchaseItemLockService',
            'name' => 'PurchaseItem Service',
            'description' => 'Reject changes to item product, original qty, price or discount after first load',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementPurchaseItemLockService',
            'method' => 'execute',
            'stages' => [
                'beforeSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'purchaseItem',
            'trigger' => 'loadedQty > 0',
        ];
    }
}
