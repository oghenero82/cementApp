<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class ReportExporterServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'ReportExporterService',
            'name' => 'Exports Service',
            'description' => 'Export report output',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\ReportExporterService',
            'method' => 'execute',
            'stages' => [
                'afterCommit',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'report_result',
            'trigger' => 'true',
        ];
    }
}
