<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class ReportEmailServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'ReportEmailService',
            'name' => 'Emails Service',
            'description' => 'Deliver generated report email',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\ReportEmailService',
            'method' => 'execute',
            'stages' => [
                'afterCommit',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'report_delivery',
            'trigger' => 'true',
        ];
    }
}
