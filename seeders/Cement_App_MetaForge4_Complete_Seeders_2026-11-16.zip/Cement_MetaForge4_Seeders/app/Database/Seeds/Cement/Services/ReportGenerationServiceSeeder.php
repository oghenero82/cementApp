<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class ReportGenerationServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'ReportGenerationService',
            'name' => 'Reports Service',
            'description' => 'Generate server_stored report snapshot (registered MetaForge service)',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\ReportGenerationService',
            'method' => 'execute',
            'stages' => [
                'afterCommit',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'report_result',
            'trigger' => 'true',
        ];
    }
}
