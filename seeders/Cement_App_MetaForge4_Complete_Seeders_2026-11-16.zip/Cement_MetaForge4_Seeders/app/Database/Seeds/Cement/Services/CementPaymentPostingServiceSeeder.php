<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementPaymentPostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementPaymentPostingService',
            'name' => 'CustomerPayment Service',
            'description' => 'Post customer receipts against receivables',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementPaymentPostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'customer_payment',
            'trigger' => 'status == "completed"',
        ];
    }
}
