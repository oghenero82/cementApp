<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementStocktakePostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementStocktakePostingService',
            'name' => 'Stocktake Service',
            'description' => 'Write approved variance adjustments and update quantities',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementStocktakePostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'inventory_stocktake',
            'trigger' => 'status == "posted"',
        ];
    }
}
