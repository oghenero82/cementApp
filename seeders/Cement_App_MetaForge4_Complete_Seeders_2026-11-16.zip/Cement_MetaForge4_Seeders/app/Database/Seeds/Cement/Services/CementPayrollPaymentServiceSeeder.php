<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementPayrollPaymentServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementPayrollPaymentService',
            'name' => 'Payrun Service',
            'description' => 'Post payroll payment and clear liability',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementPayrollPaymentService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'payroll_payment',
            'trigger' => 'status == "completed"',
        ];
    }
}
