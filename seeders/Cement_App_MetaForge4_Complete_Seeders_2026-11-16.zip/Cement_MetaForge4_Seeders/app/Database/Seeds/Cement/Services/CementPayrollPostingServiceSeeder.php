<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementPayrollPostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementPayrollPostingService',
            'name' => 'Payroll Service',
            'description' => 'Post payroll expense and deductions with cooperative savings and loan links',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementPayrollPostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'payroll',
            'trigger' => 'status == "posted"',
        ];
    }
}
