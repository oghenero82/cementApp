<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementInventoryTransferServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementInventoryTransferService',
            'name' => 'Transfer Service',
            'description' => 'Produce balanced inter-location movements',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementInventoryTransferService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'inventory_transfer',
            'trigger' => 'status == "received"',
        ];
    }
}
