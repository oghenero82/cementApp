<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementSalesPostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementSalesPostingService',
            'name' => 'SalesPosting Service',
            'description' => 'Post sale and tax to receivables / income',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementSalesPostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'customer_sales',
            'trigger' => 'status == "invoiced"',
        ];
    }
}
