<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementTripCostAllocationServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementTripCostAllocationService',
            'name' => 'TripCost Service',
            'description' => 'Allocate actual fuel, maintenance and trip expense to multiple destination sales',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementTripCostAllocationService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'trip',
            'trigger' => 'status == "completed"',
        ];
    }
}
