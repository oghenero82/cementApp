<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementSalesPricingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementSalesPricingService',
            'name' => 'PriceResolver Service',
            'description' => 'Resolve dated price tiers and snapshot agreed line price',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementSalesPricingService',
            'method' => 'execute',
            'stages' => [
                'beforeSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'customer_sale_item',
            'trigger' => 'true',
        ];
    }
}
