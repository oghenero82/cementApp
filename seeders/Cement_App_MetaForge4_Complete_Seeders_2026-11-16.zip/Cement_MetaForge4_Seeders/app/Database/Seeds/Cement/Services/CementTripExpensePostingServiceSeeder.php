<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementTripExpensePostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementTripExpensePostingService',
            'name' => 'TripExpense Service',
            'description' => 'Post trip expense GL',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementTripExpensePostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'trip_expense',
            'trigger' => 'status == "posted"',
        ];
    }
}
