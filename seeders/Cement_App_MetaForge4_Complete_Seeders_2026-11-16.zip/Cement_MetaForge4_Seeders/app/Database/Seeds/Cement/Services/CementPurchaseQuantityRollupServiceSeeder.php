<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementPurchaseQuantityRollupServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementPurchaseQuantityRollupService',
            'name' => 'PurchaseQty Service',
            'description' => 'Safely recompute purchaseItem loadedQty without external client edits',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementPurchaseQuantityRollupService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'cement_loading',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
