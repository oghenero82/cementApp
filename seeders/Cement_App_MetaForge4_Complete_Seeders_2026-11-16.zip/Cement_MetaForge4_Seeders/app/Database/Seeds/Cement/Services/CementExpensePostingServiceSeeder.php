<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementExpensePostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementExpensePostingService',
            'name' => 'Expense Service',
            'description' => 'Post approved operating expenses',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementExpensePostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'expense',
            'trigger' => 'status == "posted"',
        ];
    }
}
