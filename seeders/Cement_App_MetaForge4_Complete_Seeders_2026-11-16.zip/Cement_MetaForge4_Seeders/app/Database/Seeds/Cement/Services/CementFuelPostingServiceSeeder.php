<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementFuelPostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementFuelPostingService',
            'name' => 'Fuel Service',
            'description' => 'Post fuel payment / expense journal',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementFuelPostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'fuel_transaction',
            'trigger' => 'status == "posted"',
        ];
    }
}
