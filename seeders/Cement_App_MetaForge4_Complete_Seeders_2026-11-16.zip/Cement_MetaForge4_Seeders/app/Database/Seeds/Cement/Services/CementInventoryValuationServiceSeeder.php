<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementInventoryValuationServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementInventoryValuationService',
            'name' => 'Valuation Service',
            'description' => 'Maintain FIFO layers or weighted average per institution policy',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementInventoryValuationService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'inventory_movement',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
