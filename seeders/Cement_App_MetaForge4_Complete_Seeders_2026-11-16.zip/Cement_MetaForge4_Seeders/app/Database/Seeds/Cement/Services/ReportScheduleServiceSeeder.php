<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class ReportScheduleServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'ReportScheduleService',
            'name' => 'Schedules Service',
            'description' => 'Schedule reports for a server-side job runner',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\ReportScheduleService',
            'method' => 'execute',
            'stages' => [
                'afterCommit',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'report_schedule',
            'trigger' => 'true',
        ];
    }
}
