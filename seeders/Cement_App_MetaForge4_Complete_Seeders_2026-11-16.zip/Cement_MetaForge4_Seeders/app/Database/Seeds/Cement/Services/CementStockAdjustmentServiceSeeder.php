<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementStockAdjustmentServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementStockAdjustmentService',
            'name' => 'Adjustment Service',
            'description' => 'Create inventory movement only after approval',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementStockAdjustmentService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'stock_adjustment',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
