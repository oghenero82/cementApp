<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementIncentiveAccrualServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementIncentiveAccrualService',
            'name' => 'Incentive Service',
            'description' => 'Accrue supplier incentive or use direct actual benefit',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementIncentiveAccrualService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'supplier_incentive',
            'trigger' => 'status == "verified"',
        ];
    }
}
