<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementDeliveryAcceptanceServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementDeliveryAcceptanceService',
            'name' => 'Delivery Service',
            'description' => 'Record proof, delivery quantities and ownership transfer',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementDeliveryAcceptanceService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'delivery_proof',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
