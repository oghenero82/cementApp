<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementLoadingClearingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementLoadingClearingService',
            'name' => 'Clearance Service',
            'description' => 'Apply partial clearings to purchaseItem clearedQty',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementLoadingClearingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'loading_clearance',
            'trigger' => 'status == "verified"',
        ];
    }
}
