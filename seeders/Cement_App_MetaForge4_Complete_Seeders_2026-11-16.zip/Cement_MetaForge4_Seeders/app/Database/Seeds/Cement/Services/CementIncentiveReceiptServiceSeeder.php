<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementIncentiveReceiptServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementIncentiveReceiptService',
            'name' => 'IncentiveReceipt Service',
            'description' => 'Settle incentive receivable once',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementIncentiveReceiptService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'supplier_incentive_receipt',
            'trigger' => 'status == "completed"',
        ];
    }
}
