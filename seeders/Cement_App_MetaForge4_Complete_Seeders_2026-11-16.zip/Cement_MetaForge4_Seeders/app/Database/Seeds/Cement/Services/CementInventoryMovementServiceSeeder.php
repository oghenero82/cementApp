<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementInventoryMovementServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementInventoryMovementService',
            'name' => 'StockMovement Service',
            'description' => 'Update inventory_stock only on confirmed/effective movement',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementInventoryMovementService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'inventory_movement',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
