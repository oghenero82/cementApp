<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementSalesReturnServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementSalesReturnService',
            'name' => 'SalesReturn Service',
            'description' => 'Record sales returns, credit/refund and good/bad stock disposition',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementSalesReturnService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'customer_sale_return',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
