<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementLoadingAllocationServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementLoadingAllocationService',
            'name' => 'Loading Service',
            'description' => 'Atomically issue customer sales or inventory movement for each loading destination',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementLoadingAllocationService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'cement_loading',
            'trigger' => 'status == "confirmed"',
        ];
    }
}
