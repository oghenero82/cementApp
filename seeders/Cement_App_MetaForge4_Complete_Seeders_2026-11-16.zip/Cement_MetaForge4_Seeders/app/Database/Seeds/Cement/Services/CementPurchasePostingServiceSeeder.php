<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Services;

use App\Database\Seeds\Cement\Support\AbstractServiceRegistrationSeeder;

final class CementPurchasePostingServiceSeeder extends AbstractServiceRegistrationSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'CementPurchasePostingService',
            'name' => 'Purchase Service',
            'description' => 'Post supplier prepaid entitlement: Dr prepaid, Cr payment GL exactly once',
            'handlerClass' => 'App\\Libraries\\MetaForge\\Services\\CementPurchasePostingService',
            'method' => 'execute',
            'stages' => [
                'afterSave',
            ],
            'trustedOnly' => true,
            'handlerImplemented' => false,
            'recordTypeCode' => 'purchase',
            'trigger' => 'status == "paid"',
        ];
    }
}
