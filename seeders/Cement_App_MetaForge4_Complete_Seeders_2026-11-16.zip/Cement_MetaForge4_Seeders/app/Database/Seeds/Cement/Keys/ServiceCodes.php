<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Keys;

final class ServiceCodes
{
    public const CEMENT_PURCHASE_POSTING_SERVICE = 'CementPurchasePostingService';
    public const CEMENT_PURCHASE_ITEM_LOCK_SERVICE = 'CementPurchaseItemLockService';
    public const CEMENT_LOADING_ALLOCATION_SERVICE = 'CementLoadingAllocationService';
    public const CEMENT_LOADING_CLEARING_SERVICE = 'CementLoadingClearingService';
    public const CEMENT_PURCHASE_QUANTITY_ROLLUP_SERVICE = 'CementPurchaseQuantityRollupService';
    public const CEMENT_SALES_PRICING_SERVICE = 'CementSalesPricingService';
    public const CEMENT_SALES_POSTING_SERVICE = 'CementSalesPostingService';
    public const CEMENT_PAYMENT_POSTING_SERVICE = 'CementPaymentPostingService';
    public const CEMENT_INVENTORY_MOVEMENT_SERVICE = 'CementInventoryMovementService';
    public const CEMENT_INVENTORY_VALUATION_SERVICE = 'CementInventoryValuationService';
    public const CEMENT_STOCKTAKE_POSTING_SERVICE = 'CementStocktakePostingService';
    public const CEMENT_STOCK_ADJUSTMENT_SERVICE = 'CementStockAdjustmentService';
    public const CEMENT_INVENTORY_TRANSFER_SERVICE = 'CementInventoryTransferService';
    public const CEMENT_SALES_RETURN_SERVICE = 'CementSalesReturnService';
    public const CEMENT_DELIVERY_ACCEPTANCE_SERVICE = 'CementDeliveryAcceptanceService';
    public const CEMENT_TRIP_COST_ALLOCATION_SERVICE = 'CementTripCostAllocationService';
    public const CEMENT_FUEL_POSTING_SERVICE = 'CementFuelPostingService';
    public const CEMENT_MAINTENANCE_POSTING_SERVICE = 'CementMaintenancePostingService';
    public const CEMENT_TRIP_EXPENSE_POSTING_SERVICE = 'CementTripExpensePostingService';
    public const CEMENT_INCENTIVE_ACCRUAL_SERVICE = 'CementIncentiveAccrualService';
    public const CEMENT_INCENTIVE_RECEIPT_SERVICE = 'CementIncentiveReceiptService';
    public const CEMENT_PAYROLL_POSTING_SERVICE = 'CementPayrollPostingService';
    public const CEMENT_PAYROLL_PAYMENT_SERVICE = 'CementPayrollPaymentService';
    public const CEMENT_EXPENSE_POSTING_SERVICE = 'CementExpensePostingService';
    public const REPORT_GENERATION_SERVICE = 'ReportGenerationService';
    public const REPORT_EXPORTER_SERVICE = 'ReportExporterService';
    public const REPORT_EMAIL_SERVICE = 'ReportEmailService';
    public const REPORT_SCHEDULE_SERVICE = 'ReportScheduleService';
}
