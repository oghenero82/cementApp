<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Keys;

final class RecordTypeCodes
{
    public const PERSON = 'person';
    public const CUSTOMER = 'customer';
    public const SUPPLIER = 'supplier';
    public const SUPPLIER_DEPOT = 'supplier_depot';
    public const SUPPLIER_PRODUCT = 'supplier_product';
    public const UNIT_OF_MEASURE = 'unit_of_measure';
    public const PRODUCT_CATEGORY = 'product_category';
    public const PRODUCT = 'product';
    public const PRICE_LIST = 'price_list';
    public const PRICE_LIST_ITEM = 'price_list_item';
    public const PURCHASE = 'purchase';
    public const PURCHASE_ITEM = 'purchaseItem';
    public const CEMENT_LOADING = 'cement_loading';
    public const LOADING_CLEARANCE = 'loading_clearance';
    public const SUPPLIER_PURCHASE_PAYMENT = 'supplier_purchase_payment';
    public const PURCHASE_ADJUSTMENT = 'purchase_adjustment';
    public const CUSTOMER_SALES = 'customer_sales';
    public const CUSTOMER_SALE_ITEM = 'customer_sale_item';
    public const CUSTOMER_PAYMENT = 'customer_payment';
    public const CUSTOMER_SALE_RETURN = 'customer_sale_return';
    public const DELIVERY_PROOF = 'delivery_proof';
    public const INVENTORY_LOCATION = 'inventory_location';
    public const INVENTORY_STOCK = 'inventory_stock';
    public const INVENTORY_MOVEMENT = 'inventory_movement';
    public const INVENTORY_COST_LAYER = 'inventory_cost_layer';
    public const INVENTORY_STOCKTAKE = 'inventory_stocktake';
    public const INVENTORY_STOCKTAKE_LINE = 'inventory_stocktake_line';
    public const STOCK_ADJUSTMENT = 'stock_adjustment';
    public const DAMAGED_GOODS = 'damaged_goods';
    public const INVENTORY_TRANSFER = 'inventory_transfer';
    public const VEHICLE = 'vehicle';
    public const TRIP = 'trip';
    public const TRIP_DESTINATION = 'trip_destination';
    public const FUEL_TRANSACTION = 'fuel_transaction';
    public const VEHICLE_MAINTENANCE = 'vehicle_maintenance';
    public const TRIP_EXPENSE = 'trip_expense';
    public const SUPPLIER_INCENTIVE_SCHEME = 'supplier_incentive_scheme';
    public const SUPPLIER_INCENTIVE = 'supplier_incentive';
    public const SUPPLIER_INCENTIVE_RECEIPT = 'supplier_incentive_receipt';
    public const STAFF_EMPLOYMENT = 'staff_employment';
    public const PAYROLL = 'payroll';
    public const PAYROLL_ITEM = 'payroll_item';
    public const PAYROLL_PAYMENT = 'payroll_payment';
    public const STAFF_DEDUCTION = 'staff_deduction';
    public const EXPENSE = 'expense';
    public const REPORT = 'report';
    public const REPORT_RESULT = 'report_result';
    public const REPORT_DELIVERY = 'report_delivery';
    public const REPORT_SCHEDULE = 'report_schedule';
    public const CEMENT_BRANCH = 'cement_branch';
    public const CEMENT_AUDIT_EVENT = 'cement_audit_event';
}
