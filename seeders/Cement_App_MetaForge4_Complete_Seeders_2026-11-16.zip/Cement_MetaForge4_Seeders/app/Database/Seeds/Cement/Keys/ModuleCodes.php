<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Keys;

final class ModuleCodes
{
    public const CEMENT_MASTER = 'cement_master';
    public const CEMENT_PRICING = 'cement_pricing';
    public const CEMENT_PROCUREMENT = 'cement_procurement';
    public const CEMENT_SALES = 'cement_sales';
    public const CEMENT_INVENTORY = 'cement_inventory';
    public const CEMENT_LOGISTICS = 'cement_logistics';
    public const CEMENT_INCENTIVES = 'cement_incentives';
    public const CEMENT_PEOPLE = 'cement_people';
    public const CEMENT_FINANCE = 'cement_finance';
    public const CEMENT_ADMIN = 'cement_admin';
}
