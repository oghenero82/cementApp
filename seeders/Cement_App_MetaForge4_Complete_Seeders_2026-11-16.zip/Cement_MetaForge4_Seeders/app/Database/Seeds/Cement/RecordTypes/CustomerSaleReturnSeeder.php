<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Customer Return — one declarative reusable RecordType seed. */
final class CustomerSaleReturnSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'customer_sale_return',
            'module' => 'cement_sales',
            'name' => 'Customer Return',
            'description' => 'Customer Return record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'saleId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'customer_sales',
                ],
                [
                    'code' => 'saleItemId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'customer_sale_item',
                ],
                [
                    'code' => 'quantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'returnReason',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'disposition',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'stockMovementId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_movement',
                ],
                [
                    'code' => 'refundAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'approvedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementSalesReturnService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'approved',
                    'confirmed',
                    'rejected',
                ],
                'terminalStates' => [
                    'confirmed',
                    'rejected',
                ],
            ],
        ];
    }
}
