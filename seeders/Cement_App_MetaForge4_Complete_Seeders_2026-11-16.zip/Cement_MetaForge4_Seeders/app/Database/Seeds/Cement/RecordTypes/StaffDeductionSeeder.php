<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Staff Deduction Schedule — one declarative reusable RecordType seed. */
final class StaffDeductionSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'staff_deduction',
            'module' => 'cement_people',
            'name' => 'Staff Deduction Schedule',
            'description' => 'Staff Deduction Schedule record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'employmentId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'staff_employment',
                ],
                [
                    'code' => 'deductionType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'savingsAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'member_account',
                ],
                [
                    'code' => 'loanAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'member_account',
                ],
                [
                    'code' => 'fixedAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'rate',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'startDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'endDate',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'currentBalance',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
