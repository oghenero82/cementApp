<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Cement Loading — one declarative reusable RecordType seed. */
final class CementLoadingSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_loading',
            'module' => 'cement_procurement',
            'name' => 'Cement Loading',
            'description' => 'Confirmed allocations issue customer_sales for customer quantity or inventory_movement for warehouse quantity',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'purchaseItemId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'purchaseItem',
                ],
                [
                    'code' => 'supplierDepotId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'supplier_depot',
                ],
                [
                    'code' => 'supplierLoadingNo',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'supplierPin',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'supplierBin',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'loadingDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'truckId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'vehicle',
                ],
                [
                    'code' => 'driverId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'quantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityBase',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'unitConversionSnapshot',
                    'type' => 'object',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'customerQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'warehouseQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'clearedQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'destinations',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'allocationRows',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'tripId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'trip',
                ],
                [
                    'code' => 'confirmedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'confirmedAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'notes',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementLoadingAllocationService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
                [
                    'code' => 'CementPurchaseQuantityRollupService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'submitted',
                    'confirmed',
                    'cancelled',
                ],
                'terminalStates' => [
                    'confirmed',
                    'cancelled',
                ],
            ],
        ];
    }
}
