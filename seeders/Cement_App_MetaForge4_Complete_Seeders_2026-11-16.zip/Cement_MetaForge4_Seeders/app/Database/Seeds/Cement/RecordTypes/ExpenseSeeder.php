<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** General Expense — one declarative reusable RecordType seed. */
final class ExpenseSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'expense',
            'module' => 'cement_finance',
            'name' => 'General Expense',
            'description' => 'General Expense record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'expenseDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'expenseType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'description',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'taxAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'supplierId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'supplier',
                ],
                [
                    'code' => 'vehicleId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'vehicle',
                ],
                [
                    'code' => 'tripId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'trip',
                ],
                [
                    'code' => 'employeeId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'staff_employment',
                ],
                [
                    'code' => 'paymentAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'expenseAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'reference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementExpensePostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "posted"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'approved',
                    'posted',
                    'cancelled',
                ],
                'terminalStates' => [
                    'posted',
                    'cancelled',
                ],
            ],
        ];
    }
}
