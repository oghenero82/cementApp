<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Stock Adjustment — one declarative reusable RecordType seed. */
final class StockAdjustmentSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'stock_adjustment',
            'module' => 'cement_inventory',
            'name' => 'Stock Adjustment',
            'description' => 'Approval before stock movements; positive/negative adjustment and stock condition supported',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'locationId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'adjustmentDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'reasonCode',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'stockCondition',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityDelta',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'stocktakeLineId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_stocktake_line',
                ],
                [
                    'code' => 'sourceMovementId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_movement',
                ],
                [
                    'code' => 'approvedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'approvalDate',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementStockAdjustmentService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'pending_approval',
                    'approved',
                    'confirmed',
                    'rejected',
                ],
                'terminalStates' => [
                    'confirmed',
                    'rejected',
                ],
            ],
        ];
    }
}
