<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Customer Payment — one declarative reusable RecordType seed. */
final class CustomerPaymentSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'customer_payment',
            'module' => 'cement_sales',
            'name' => 'Customer Payment',
            'description' => 'Customer Payment record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'customerId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'customer',
                ],
                [
                    'code' => 'saleId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'customer_sales',
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paymentDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paymentMethod',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'bankAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'bank_account',
                ],
                [
                    'code' => 'reference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'postedJournalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementPaymentPostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "completed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'completed',
                    'cancelled',
                ],
                'terminalStates' => [
                    'completed',
                    'cancelled',
                ],
            ],
        ];
    }
}
