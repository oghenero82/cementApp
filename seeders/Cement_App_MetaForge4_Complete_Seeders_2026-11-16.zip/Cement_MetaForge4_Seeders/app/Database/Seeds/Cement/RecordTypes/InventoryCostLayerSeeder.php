<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** FIFO Cost Layer — one declarative reusable RecordType seed. */
final class InventoryCostLayerSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'inventory_cost_layer',
            'module' => 'cement_inventory',
            'name' => 'FIFO Cost Layer',
            'description' => 'Ledger of immutable FIFO receipt layers, consumed by valuation service',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'stockId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_stock',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'locationId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'sourceMovementId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_movement',
                ],
                [
                    'code' => 'receiptDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'originalQty',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'remainingQty',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitCost',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
