<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Supplier Incentive Receipt — one declarative reusable RecordType seed. */
final class SupplierIncentiveReceiptSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'supplier_incentive_receipt',
            'module' => 'cement_incentives',
            'name' => 'Supplier Incentive Receipt',
            'description' => 'Supplier Incentive Receipt record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'incentiveId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'supplier_incentive',
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'receivedDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'bankAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'bank_account',
                ],
                [
                    'code' => 'reference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementIncentiveReceiptService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "completed"',
                ],
            ],
        ];
    }
}
