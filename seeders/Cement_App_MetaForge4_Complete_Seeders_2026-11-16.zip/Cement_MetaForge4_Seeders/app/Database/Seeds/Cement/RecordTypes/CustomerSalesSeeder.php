<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Customer Sale — one declarative reusable RecordType seed. */
final class CustomerSalesSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'customer_sales',
            'module' => 'cement_sales',
            'name' => 'Customer Sale',
            'description' => 'Sale header linked to supplier loading or warehouse stock, preserving price and ownership policy',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'customerId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'customer',
                ],
                [
                    'code' => 'saleDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'sourceLoadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'sourceTripId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'trip',
                ],
                [
                    'code' => 'warehouseId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'priceListId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'price_list',
                ],
                [
                    'code' => 'currency',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'grossAmount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'discountAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'taxAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'netAmount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'amountPaid',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'balanceDue',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paymentTermsDays',
                    'type' => 'integer',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'ownershipTransferPolicy',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'deliveredAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'deliveryStatus',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementSalesPostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "invoiced"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'confirmed',
                    'part_delivered',
                    'delivered',
                    'invoiced',
                    'paid',
                    'cancelled',
                ],
                'terminalStates' => [
                    'paid',
                    'cancelled',
                ],
            ],
        ];
    }
}
