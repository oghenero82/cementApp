<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Supplier Incentive Scheme — one declarative reusable RecordType seed. */
final class SupplierIncentiveSchemeSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'supplier_incentive_scheme',
            'module' => 'cement_incentives',
            'name' => 'Supplier Incentive Scheme',
            'description' => 'Supplier Incentive Scheme record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'supplierId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'supplier',
                ],
                [
                    'code' => 'name',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'basis',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'calculationType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'rate',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'fixedAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'thresholdQty',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'thresholdAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'validFrom',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'validTo',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'productIds',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'depotIds',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
