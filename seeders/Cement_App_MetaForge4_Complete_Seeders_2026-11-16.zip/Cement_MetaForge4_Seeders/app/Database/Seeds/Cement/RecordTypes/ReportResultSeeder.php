<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Stored Report Result — one declarative reusable RecordType seed. */
final class ReportResultSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'report_result',
            'module' => 'cement_finance',
            'name' => 'Stored Report Result',
            'description' => 'Stored server generated report snapshots',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'reportId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'report',
                ],
                [
                    'code' => 'generatedAt',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'periodStart',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'periodEnd',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'parameters',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totals',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'rows',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'artifactPath',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'fileType',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'generatedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'ReportGenerationService',
                    'stage' => 'afterCommit',
                    'trigger' => 'true',
                ],
                [
                    'code' => 'ReportExporterService',
                    'stage' => 'afterCommit',
                    'trigger' => 'true',
                ],
            ],
        ];
    }
}
