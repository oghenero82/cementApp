<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Customer Sale Item — one declarative reusable RecordType seed. */
final class CustomerSaleItemSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'customer_sale_item',
            'module' => 'cement_sales',
            'name' => 'Customer Sale Item',
            'description' => 'Each line stores the actual agreed unit price, discount and conversion snapshot',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'saleId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'customer_sales',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'quantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityBase',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'listedUnitPrice',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'agreedUnitPrice',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'discountType',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'discountValue',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'netUnitPrice',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'taxRate',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'taxAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'lineAmount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'priceListItemId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'price_list_item',
                ],
                [
                    'code' => 'sourcePurchaseItemId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'purchaseItem',
                ],
                [
                    'code' => 'sourceLoadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'sourceMovementId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_movement',
                ],
                [
                    'code' => 'unitConversionSnapshot',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementSalesPricingService',
                    'stage' => 'beforeSave',
                    'trigger' => 'true',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'open',
                'states' => [
                    'open',
                    'delivered',
                    'returned',
                    'cancelled',
                ],
                'terminalStates' => [
                    'returned',
                    'cancelled',
                ],
            ],
        ];
    }
}
