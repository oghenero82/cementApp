<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Vehicle Maintenance — one declarative reusable RecordType seed. */
final class VehicleMaintenanceSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'vehicle_maintenance',
            'module' => 'cement_logistics',
            'name' => 'Vehicle Maintenance',
            'description' => 'Vehicle Maintenance record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'vehicleId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'vehicle',
                ],
                [
                    'code' => 'tripId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'trip',
                ],
                [
                    'code' => 'serviceDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'maintenanceType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'description',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'serviceProvider',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'odometer',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'partsCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'laborCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalCost',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paymentAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'nextServiceDate',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementMaintenancePostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "posted"',
                ],
            ],
        ];
    }
}
