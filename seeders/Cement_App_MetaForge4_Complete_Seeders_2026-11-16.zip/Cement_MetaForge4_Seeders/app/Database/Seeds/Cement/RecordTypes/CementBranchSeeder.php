<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Branch — one declarative reusable RecordType seed. */
final class CementBranchSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_branch',
            'module' => 'cement_admin',
            'name' => 'Branch',
            'description' => 'Branch record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'name',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'address',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'defaultDepotId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'supplier_depot',
                ],
                [
                    'code' => 'defaultWarehouseId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'defaultBankAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'bank_account',
                ],
                [
                    'code' => 'managerId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
