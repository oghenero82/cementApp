<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Inventory Movement — one declarative reusable RecordType seed. */
final class InventoryMovementSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'inventory_movement',
            'module' => 'cement_inventory',
            'name' => 'Inventory Movement',
            'description' => 'Only effective confirmed movements affect inventory_stock; stock is updated by authorized service/RA',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'movementDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'movementType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'sourceLocationId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'destinationLocationId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'stockCondition',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'qtyBase',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'unitConversionSnapshot',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'costPolicy',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'sourceRecordTypeCode',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'sourceRecordId',
                    'type' => 'integer',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'purchaseItemId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'purchaseItem',
                ],
                [
                    'code' => 'loadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'saleItemId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'customer_sale_item',
                ],
                [
                    'code' => 'fifoAllocations',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'authorizedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'effectiveAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementInventoryMovementService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
                [
                    'code' => 'CementInventoryValuationService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'approved',
                    'confirmed',
                    'reversed',
                ],
                'terminalStates' => [
                    'reversed',
                ],
            ],
        ];
    }
}
