<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Inventory Stock — one declarative reusable RecordType seed. */
final class InventoryStockSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'inventory_stock',
            'module' => 'cement_inventory',
            'name' => 'Inventory Stock',
            'description' => 'System managed balance; no direct human quantity edits; unique location/product/condition',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'locationId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'stockCondition',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityOnHand',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityReserved',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityAvailable',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'averageUnitCost',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'totalValue',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'lastMovementAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'lastStocktakeAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
