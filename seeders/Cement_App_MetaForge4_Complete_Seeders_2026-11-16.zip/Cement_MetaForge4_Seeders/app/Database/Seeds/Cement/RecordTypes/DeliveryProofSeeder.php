<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Delivery Proof — one declarative reusable RecordType seed. */
final class DeliveryProofSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'delivery_proof',
            'module' => 'cement_sales',
            'name' => 'Delivery Proof',
            'description' => 'Delivery Proof record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'saleId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'customer_sales',
                ],
                [
                    'code' => 'tripDestinationId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'trip_destination',
                ],
                [
                    'code' => 'deliveredDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'acceptedQuantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'rejectedQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'signature',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'photos',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'receiverName',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'receiverPhone',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'deliveryNoteNo',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementDeliveryAcceptanceService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "confirmed"',
                ],
            ],
        ];
    }
}
