<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Inventory Transfer — one declarative reusable RecordType seed. */
final class InventoryTransferSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'inventory_transfer',
            'module' => 'cement_inventory',
            'name' => 'Inventory Transfer',
            'description' => 'Inventory Transfer record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'sourceLocationId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'destinationLocationId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'quantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'requestDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'dispatchedAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'receivedAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'outMovementId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_movement',
                ],
                [
                    'code' => 'inMovementId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_movement',
                ],
                [
                    'code' => 'approvedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementInventoryTransferService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "received"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'approved',
                    'dispatched',
                    'received',
                    'cancelled',
                ],
                'terminalStates' => [
                    'received',
                    'cancelled',
                ],
            ],
        ];
    }
}
