<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Trip Destination — one declarative reusable RecordType seed. */
final class TripDestinationSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'trip_destination',
            'module' => 'cement_logistics',
            'name' => 'Trip Destination',
            'description' => 'Trip Destination record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'tripId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'trip',
                ],
                [
                    'code' => 'destinationOrder',
                    'type' => 'integer',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'customerId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'customer',
                ],
                [
                    'code' => 'deliveryAddress',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'saleId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'customer_sales',
                ],
                [
                    'code' => 'loadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'product',
                ],
                [
                    'code' => 'quantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'arrivalAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'deliveredAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'proofId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'delivery_proof',
                ],
                [
                    'code' => 'deliveryStatus',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'notes',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
