<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Supplier Product Mapping — one declarative reusable RecordType seed. */
final class SupplierProductSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'supplier_product',
            'module' => 'cement_master',
            'name' => 'Supplier Product Mapping',
            'description' => 'Supplier Product Mapping record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'supplierId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'supplier',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'supplierProductCode',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'productNameAtSupplier',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'depotIds',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'minOrderQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'active',
                    'type' => 'boolean',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
