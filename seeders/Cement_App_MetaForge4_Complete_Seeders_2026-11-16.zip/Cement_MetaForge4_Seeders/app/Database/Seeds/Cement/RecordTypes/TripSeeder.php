<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Delivery Trip — one declarative reusable RecordType seed. */
final class TripSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'trip',
            'module' => 'cement_logistics',
            'name' => 'Delivery Trip',
            'description' => 'One truck trip can deliver to several customers/destinations',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'vehicleId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'vehicle',
                ],
                [
                    'code' => 'driverId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'person',
                ],
                [
                    'code' => 'loadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'originDepotId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'supplier_depot',
                ],
                [
                    'code' => 'originLocationId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'departureAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'arrivalAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'scheduledDate',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'destinationCount',
                    'type' => 'integer',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalFuelCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalMaintenanceCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalTripExpense',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'totalTripCost',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'notes',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementTripCostAllocationService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "completed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'planned',
                'states' => [
                    'planned',
                    'loading',
                    'dispatched',
                    'in_transit',
                    'completed',
                    'cancelled',
                ],
                'terminalStates' => [
                    'completed',
                    'cancelled',
                ],
            ],
        ];
    }
}
