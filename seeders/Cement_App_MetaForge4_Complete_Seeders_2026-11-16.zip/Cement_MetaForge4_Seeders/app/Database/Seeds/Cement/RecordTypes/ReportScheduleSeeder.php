<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Report Schedule — one declarative reusable RecordType seed. */
final class ReportScheduleSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'report_schedule',
            'module' => 'cement_finance',
            'name' => 'Report Schedule',
            'description' => 'Report Schedule record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'reportId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'report',
                ],
                [
                    'code' => 'cadence',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'timezone',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'recipients',
                    'type' => 'array',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'outputFormat',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'enabled',
                    'type' => 'boolean',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'lastRunAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'nextRunAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'ReportScheduleService',
                    'stage' => 'afterCommit',
                    'trigger' => 'true',
                ],
            ],
        ];
    }
}
