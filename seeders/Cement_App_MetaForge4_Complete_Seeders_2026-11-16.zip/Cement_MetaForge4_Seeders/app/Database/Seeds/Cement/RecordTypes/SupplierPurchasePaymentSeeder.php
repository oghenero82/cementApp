<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Supplier Payment — one declarative reusable RecordType seed. */
final class SupplierPurchasePaymentSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'supplier_purchase_payment',
            'module' => 'cement_procurement',
            'name' => 'Supplier Payment',
            'description' => 'Supplier Payment record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'purchaseId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'purchase',
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paidAt',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paymentMethod',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'bankAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'bank_account',
                ],
                [
                    'code' => 'reference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
