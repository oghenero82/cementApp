<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Loading Clearance — one declarative reusable RecordType seed. */
final class LoadingClearanceSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'loading_clearance',
            'module' => 'cement_procurement',
            'name' => 'Loading Clearance',
            'description' => 'Loading Clearance record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'purchaseItemId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'purchaseItem',
                ],
                [
                    'code' => 'loadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'supplierClearingRef',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'clearanceDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'supplierDocument',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'verifiedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementLoadingClearingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "verified"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'verified',
                    'cancelled',
                ],
                'terminalStates' => [
                    'verified',
                    'cancelled',
                ],
            ],
        ];
    }
}
