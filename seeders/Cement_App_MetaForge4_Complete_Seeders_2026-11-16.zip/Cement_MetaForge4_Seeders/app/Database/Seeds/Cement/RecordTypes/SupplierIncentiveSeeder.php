<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Supplier Incentive Benefit — one declarative reusable RecordType seed. */
final class SupplierIncentiveSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'supplier_incentive',
            'module' => 'cement_incentives',
            'name' => 'Supplier Incentive Benefit',
            'description' => 'Handles optional scheme or directly entered actual benefit based on purchase or loading',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'supplierId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'supplier',
                ],
                [
                    'code' => 'schemeId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'supplier_incentive_scheme',
                ],
                [
                    'code' => 'purchaseId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'purchase',
                ],
                [
                    'code' => 'loadingId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'cement_loading',
                ],
                [
                    'code' => 'benefitDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'benefitType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'basisQuantity',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'basisAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'rate',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'actualAmount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'amountReceived',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'receivableAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'incomeAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementIncentiveAccrualService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "verified"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'pending',
                'states' => [
                    'pending',
                    'verified',
                    'part_received',
                    'received',
                    'rejected',
                ],
                'terminalStates' => [
                    'received',
                    'rejected',
                ],
            ],
        ];
    }
}
