<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Purchase Item — one declarative reusable RecordType seed. */
final class PurchaseItemSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'purchaseItem',
            'module' => 'cement_procurement',
            'name' => 'Purchase Item',
            'description' => 'Generic root purchaseItem; product/quantity/price/discount immutable after first loadedQty > 0',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'purchaseId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'purchase',
                ],
                [
                    'code' => 'supplierProductId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'supplier_product',
                ],
                [
                    'code' => 'productId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product',
                ],
                [
                    'code' => 'unitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'originalQuantity',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'quantityBase',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitConversionSnapshot',
                    'type' => 'object',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'unitPrice',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'discountType',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'discountValue',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'netUnitCost',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'loadedQty',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'clearedQty',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'deliveredQty',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'fullyDelivered',
                    'type' => 'boolean',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'firstLoadedAt',
                    'type' => 'datetime',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'batchReference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementPurchaseItemLockService',
                    'stage' => 'beforeSave',
                    'trigger' => 'loadedQty > 0',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'open',
                'states' => [
                    'open',
                    'part_loaded',
                    'fully_loaded',
                    'closed',
                ],
                'terminalStates' => [
                    'closed',
                ],
            ],
        ];
    }
}
