<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Staff Employment — one declarative reusable RecordType seed. */
final class StaffEmploymentSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'staff_employment',
            'module' => 'cement_people',
            'name' => 'Staff Employment',
            'description' => 'Staff Employment record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'personId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'person',
                ],
                [
                    'code' => 'employeeNumber',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'department',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'designation',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'hireDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'terminationDate',
                    'type' => 'date',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'managerEmploymentId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'staff_employment',
                ],
                [
                    'code' => 'employmentType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'basicSalary',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'defaultBankAccount',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'payrollAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'cooperativeMemberId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'member',
                ],
                [
                    'code' => 'defaultSavingsAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'member_account',
                ],
                [
                    'code' => 'defaultLoanAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'member_account',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
