<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Stocktake — one declarative reusable RecordType seed. */
final class InventoryStocktakeSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'inventory_stocktake',
            'module' => 'cement_inventory',
            'name' => 'Stocktake',
            'description' => 'Stocktake record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'locationId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'inventory_location',
                ],
                [
                    'code' => 'countDate',
                    'type' => 'datetime',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'inventoryKeepingMethod',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'reference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'countedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'verifiedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'postedBy',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'person',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementStocktakePostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "posted"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'counting',
                    'review',
                    'approved',
                    'posted',
                    'cancelled',
                ],
                'terminalStates' => [
                    'posted',
                    'cancelled',
                ],
            ],
        ];
    }
}
