<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Payroll Payment — one declarative reusable RecordType seed. */
final class PayrollPaymentSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'payroll_payment',
            'module' => 'cement_people',
            'name' => 'Payroll Payment',
            'description' => 'Payroll Payment record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'payrollItemId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'payroll_item',
                ],
                [
                    'code' => 'employmentId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'staff_employment',
                ],
                [
                    'code' => 'paidDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paymentMethod',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'bankAccount',
                    'type' => 'object',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'paymentAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'transferReference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementPayrollPaymentService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "completed"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'completed',
                    'failed',
                ],
                'terminalStates' => [
                    'completed',
                    'failed',
                ],
            ],
        ];
    }
}
