<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Product — one declarative reusable RecordType seed. */
final class ProductSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'product',
            'module' => 'cement_master',
            'name' => 'Product',
            'description' => 'Reusable Product: immutable historical quantity conversions through transaction snapshots, no editable stock',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'name',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'categoryId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'product_category',
                ],
                [
                    'code' => 'brand',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'grade',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'description',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'baseUnitId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'packageUnitId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'unit_of_measure',
                ],
                [
                    'code' => 'packageSize',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'packageWeightKg',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'unitsPerBag',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'bagsPerPallet',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'trackingMode',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'inventoryTracked',
                    'type' => 'boolean',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'taxable',
                    'type' => 'boolean',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
        ];
    }
}
