<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Supplier Purchase — one declarative reusable RecordType seed. */
final class PurchaseSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'purchase',
            'module' => 'cement_procurement',
            'name' => 'Supplier Purchase',
            'description' => 'Root batch purchase; posts prepaid/entitlement against payment account only once',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'supplierId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'supplier',
                ],
                [
                    'code' => 'supplierDepotId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'supplier_depot',
                ],
                [
                    'code' => 'purchaseDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'supplierOrderNo',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'supplierPin',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'supplierBin',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'supplierLoginCode',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'currency',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'exchangeRate',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'paymentAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'prepaidAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'grossAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'discountAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'netAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'paidAmount',
                    'type' => 'number',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'ownershipTransferPolicy',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'notes',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementPurchasePostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "paid"',
                ],
            ],
            'lifecycle' => [
                'fieldCode' => 'status',
                'initialState' => 'draft',
                'states' => [
                    'draft',
                    'approved',
                    'paid',
                    'part_loaded',
                    'fully_loaded',
                    'closed',
                    'cancelled',
                ],
                'terminalStates' => [
                    'closed',
                    'cancelled',
                ],
            ],
        ];
    }
}
