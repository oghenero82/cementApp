<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\RecordTypes;

use App\Database\Seeds\Cement\Support\AbstractRecordTypeSeeder;

/** Trip Expense — one declarative reusable RecordType seed. */
final class TripExpenseSeeder extends AbstractRecordTypeSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'trip_expense',
            'module' => 'cement_logistics',
            'name' => 'Trip Expense',
            'description' => 'Trip Expense record',
            'fields' => [
                [
                    'code' => 'code',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'tripId',
                    'type' => 'reference',
                    'required' => true,
                    'target' => 'trip',
                ],
                [
                    'code' => 'tripDestinationId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'trip_destination',
                ],
                [
                    'code' => 'expenseType',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'expenseDate',
                    'type' => 'date',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'amount',
                    'type' => 'number',
                    'required' => true,
                    'target' => null,
                ],
                [
                    'code' => 'paidTo',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'paymentAccountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'accountId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'account',
                ],
                [
                    'code' => 'reference',
                    'type' => 'string',
                    'required' => false,
                    'target' => null,
                ],
                [
                    'code' => 'allocatedToSaleId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'customer_sales',
                ],
                [
                    'code' => 'journalId',
                    'type' => 'reference',
                    'required' => false,
                    'target' => 'journal',
                ],
                [
                    'code' => 'status',
                    'type' => 'string',
                    'required' => true,
                    'target' => null,
                ],
            ],
            'services' => [
                [
                    'code' => 'CementTripExpensePostingService',
                    'stage' => 'afterSave',
                    'trigger' => 'status == "posted"',
                ],
            ],
        ];
    }
}
