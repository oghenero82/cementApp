<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement;

use InvalidArgumentException;

/**
 * Optional institution-specific starter mutations. DO NOT insert into mf_system
 * or tenant physical tables directly; send these envelopes through MetaForge's
 * authenticated, authorized, idempotent Mutation API.
 */
final class TenantStarterMutationFactory
{
    /** @return list<array<string,mixed>> */
    public static function reportMutations(int $institutionId, int $reportRecordTypeId): array
    {
        if ($institutionId <= 0 || $reportRecordTypeId <= 0) {
            throw new InvalidArgumentException('Valid institution and report RecordType IDs required.');
        }
        $out = [];
        foreach (ReportTemplateCatalog::templates() as $report) {
            $out[] = [
                'requestId' => self::requestId($institutionId, 'cement.report.' . $report['code']),
                'mode' => 'record',
                'recordTypeId' => $reportRecordTypeId,
                'operation' => 'insert',
                'data' => [
                    'code' => $report['code'],
                    'name' => $report['name'],
                    'moduleCode' => $report['moduleCode'],
                    'generationMode' => $report['generationMode'],
                    'sourceRecordTypes' => $report['sourceRecordTypes'],
                    'groupings' => [$report['defaultGrouping']],
                    'columns' => [],
                    'filters' => [],
                    'calculations' => [],
                    'outputFormats' => $report['outputFormats'],
                    'isActive' => $report['isActive'],
                    'status' => 'active',
                ],
            ];
        }
        return $out;
    }

    /**
     * Generates a deterministic RFC 4122 v5 UUID for retries. The API's
     * institutionId is taken from the authenticated session, never this input.
     */
    private static function requestId(int $institutionId, string $key): string
    {
        $ns = hex2bin('90d57120b5cb4d519f683029a46f4cd6');
        if ($ns === false) {
            throw new \LogicException('Invalid namespace UUID constant.');
        }
        $hash = sha1($ns . $institutionId . ':' . $key);
        $hash = substr($hash, 0, 12) . '5' . substr($hash, 13, 3)
            . dechex((hexdec($hash[16]) & 0x3) | 0x8) . substr($hash, 17);
        return substr($hash, 0, 8) . '-' . substr($hash, 8, 4) . '-'
            . substr($hash, 12, 4) . '-' . substr($hash, 16, 4) . '-'
            . substr($hash, 20, 12);
    }

    /** Return a merged institution.settings payload, not a separate RT. */
    public static function mergeInstitutionSettings(array $existing): array
    {
        foreach (InstitutionPolicyCatalog::definitions() as $key => $definition) {
            if (!array_key_exists($key, $existing)) {
                $existing[$key] = $definition['default'];
            }
        }
        return $existing;
    }
}
