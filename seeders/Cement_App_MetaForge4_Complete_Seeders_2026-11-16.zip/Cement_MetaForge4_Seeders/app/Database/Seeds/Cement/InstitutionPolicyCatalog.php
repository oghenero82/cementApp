<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement;

/** Field contract to merge into existing institution.settings via MetaForge mutation. */
final class InstitutionPolicyCatalog
{
    public static function definitions(): array
    {
        return [
            'ownershipTransferPolicy' => [
                'type' => 'string',
                'default' => 'loading-transfer',
                'enum' => [
                    'loading-transfer',
                    'delivery-transfer',
                ],
            ],
            'inventoryKeepingMethod' => [
                'type' => 'string',
                'default' => 'manual_stocktaken',
                'enum' => [
                    'fixed',
                    'daily',
                    'weekly',
                    'monthly',
                    'yearly',
                    'manual_stocktaken',
                ],
            ],
            'inventoryValuationMethod' => [
                'type' => 'string',
                'default' => 'weighted_average',
                'enum' => [
                    'fifo',
                    'weighted_average',
                ],
            ],
            'enableIncentiveSchemes' => [
                'type' => 'boolean',
                'default' => false,
            ],
            'enableCashTransferPosting' => [
                'type' => 'boolean',
                'default' => false,
            ],
            'allowSalesPriceOverride' => [
                'type' => 'boolean',
                'default' => false,
            ],
            'requireLoadingApproval' => [
                'type' => 'boolean',
                'default' => true,
            ],
            'requireStockAdjustmentApproval' => [
                'type' => 'boolean',
                'default' => true,
            ],
            'loadingClearingMode' => [
                'type' => 'string',
                'default' => 'partial',
                'enum' => [
                    'partial',
                    'full_only',
                ],
            ],
            'allowCreditSales' => [
                'type' => 'boolean',
                'default' => true,
            ],
            'defaultCurrency' => [
                'type' => 'string',
                'default' => 'NGN',
            ],
            'supplierDocumentFields' => [
                'type' => 'array',
                'default' => [
                    'supplierPin',
                    'supplierBin',
                    'supplierLoginCode',
                ],
            ],
        ];
    }
}
