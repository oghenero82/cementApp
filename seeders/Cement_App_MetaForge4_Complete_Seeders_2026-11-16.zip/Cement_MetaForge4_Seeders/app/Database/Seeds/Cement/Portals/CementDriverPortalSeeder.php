<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Portals;

use App\Database\Seeds\Cement\Support\AbstractPortalSeeder;

final class CementDriverPortalSeeder extends AbstractPortalSeeder
{
    public static function specification(): array
    {
        return [
            'code' => 'cement_driver_portal',
            'name' => 'Driver Portal',
            'roleTemplate' => 'cement_driver',
            'modules' => [
                'cement_logistics',
                'cement_sales',
            ],
            'navigation' => [
                [
                    'code' => 'cement_driver.dashboard',
                    'label' => 'Dashboard',
                    'icon' => 'layout-dashboard',
                    'routeCode' => 'cement.cement_driver.dashboard',
                    'issection' => false,
                    'visible' => true,
                    'position' => 1,
                ],
                [
                    'code' => 'cement_driver.cement_logistics',
                    'label' => 'Fleet & Trips',
                    'icon' => 'folder',
                    'issection' => true,
                    'visible' => true,
                    'position' => 2,
                    'children' => [
                        [
                            'code' => 'cement_driver.vehicle',
                            'label' => 'Vehicle',
                            'icon' => 'folder-open',
                            'routeCode' => 'cement.vehicle.list',
                            'issection' => false,
                            'visible' => true,
                            'position' => 1,
                        ],
                        [
                            'code' => 'cement_driver.trip',
                            'label' => 'Delivery Trip',
                            'icon' => 'folder-open',
                            'routeCode' => 'cement.trip.list',
                            'issection' => false,
                            'visible' => true,
                            'position' => 2,
                        ],
                        [
                            'code' => 'cement_driver.trip_destination',
                            'label' => 'Trip Destination',
                            'icon' => 'folder-open',
                            'routeCode' => 'cement.trip_destination.list',
                            'issection' => false,
                            'visible' => true,
                            'position' => 3,
                        ],
                        [
                            'code' => 'cement_driver.fuel_transaction',
                            'label' => 'Fuel Transaction',
                            'icon' => 'folder-open',
                            'routeCode' => 'cement.fuel_transaction.list',
                            'issection' => false,
                            'visible' => true,
                            'position' => 4,
                        ],
                    ],
                ],
                [
                    'code' => 'cement_driver.cement_sales',
                    'label' => 'Sales & Receivables',
                    'icon' => 'folder',
                    'issection' => true,
                    'visible' => true,
                    'position' => 3,
                    'children' => [
                        [
                            'code' => 'cement_driver.delivery_proof',
                            'label' => 'Delivery Proof',
                            'icon' => 'folder-open',
                            'routeCode' => 'cement.delivery_proof.list',
                            'issection' => false,
                            'visible' => true,
                            'position' => 1,
                        ],
                    ],
                ],
            ],
            'settings' => [
                'defaultRoute' => 'cement.cement_driver.dashboard',
                'brand' => 'Cement App',
                'icon' => 'factory',
            ],
            'routes' => [
                'cement.cement_driver.dashboard',
                'cement.reports.dashboard',
                'cement.customer_sales.list',
                'cement.customer_sales.new',
                'cement.customer_sales.view',
                'cement.customer_sales.edit',
                'cement.customer_sale_item.list',
                'cement.customer_sale_item.new',
                'cement.customer_sale_item.view',
                'cement.customer_sale_item.edit',
                'cement.customer_payment.list',
                'cement.customer_payment.new',
                'cement.customer_payment.view',
                'cement.customer_payment.edit',
                'cement.customer_sale_return.list',
                'cement.customer_sale_return.new',
                'cement.customer_sale_return.view',
                'cement.customer_sale_return.edit',
                'cement.delivery_proof.list',
                'cement.delivery_proof.new',
                'cement.delivery_proof.view',
                'cement.delivery_proof.edit',
                'cement.vehicle.list',
                'cement.vehicle.new',
                'cement.vehicle.view',
                'cement.vehicle.edit',
                'cement.trip.list',
                'cement.trip.new',
                'cement.trip.view',
                'cement.trip.edit',
                'cement.trip_destination.list',
                'cement.trip_destination.new',
                'cement.trip_destination.view',
                'cement.trip_destination.edit',
                'cement.fuel_transaction.list',
                'cement.fuel_transaction.new',
                'cement.fuel_transaction.view',
                'cement.fuel_transaction.edit',
                'cement.vehicle_maintenance.list',
                'cement.vehicle_maintenance.new',
                'cement.vehicle_maintenance.view',
                'cement.vehicle_maintenance.edit',
                'cement.trip_expense.list',
                'cement.trip_expense.new',
                'cement.trip_expense.view',
                'cement.trip_expense.edit',
                'cement.sales.dashboard',
                'cement.logistics.dashboard',
            ],
        ];
    }
}
