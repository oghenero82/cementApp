<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement;

/** Installation inputs; institution-specific settings are not inserted here. */
final class CementSeedConfig
{
    public const TABLE_SYSTEM = 'mf_system';
    public const DEFAULT_STATUS = 1;

    public static function physicalTableCode(): string
    {
        return trim((string)(getenv('CEMENT_RECORD_PHYSICAL_TABLE_CODE') ?: ''));
    }
    public static function serviceRegistryCode(): string
    {
        return trim((string)(getenv('CEMENT_SERVICE_RECORDTYPE_CODE') ?: ''));
    }
    public static function seedServiceRecords(): bool
    {
        return getenv('CEMENT_SEED_SERVICE_RECORDS') === '1';
    }
    public static function strict(): bool
    {
        return getenv('CEMENT_STRICT_EXISTING') === '1';
    }
    public static function dryRun(): bool
    {
        return getenv('CEMENT_SEED_DRY_RUN') === '1';
    }
}
