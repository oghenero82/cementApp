<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement;

/** Immutable in-code seed catalog, no runtime metadata hardcoding in controllers. */
final class CementCatalog
{
    public static function modules(): array
    {
        return [
            'cement_master' => \App\Database\Seeds\Cement\Modules\CementMasterSeeder::specification(),
            'cement_pricing' => \App\Database\Seeds\Cement\Modules\CementPricingSeeder::specification(),
            'cement_procurement' => \App\Database\Seeds\Cement\Modules\CementProcurementSeeder::specification(),
            'cement_sales' => \App\Database\Seeds\Cement\Modules\CementSalesSeeder::specification(),
            'cement_inventory' => \App\Database\Seeds\Cement\Modules\CementInventorySeeder::specification(),
            'cement_logistics' => \App\Database\Seeds\Cement\Modules\CementLogisticsSeeder::specification(),
            'cement_incentives' => \App\Database\Seeds\Cement\Modules\CementIncentivesSeeder::specification(),
            'cement_people' => \App\Database\Seeds\Cement\Modules\CementPeopleSeeder::specification(),
            'cement_finance' => \App\Database\Seeds\Cement\Modules\CementFinanceSeeder::specification(),
            'cement_admin' => \App\Database\Seeds\Cement\Modules\CementAdminSeeder::specification(),
        ];
    }

    public static function recordTypes(): array
    {
        return [
            'person' => \App\Database\Seeds\Cement\RecordTypes\PersonSeeder::specification(),
            'customer' => \App\Database\Seeds\Cement\RecordTypes\CustomerSeeder::specification(),
            'supplier' => \App\Database\Seeds\Cement\RecordTypes\SupplierSeeder::specification(),
            'supplier_depot' => \App\Database\Seeds\Cement\RecordTypes\SupplierDepotSeeder::specification(),
            'supplier_product' => \App\Database\Seeds\Cement\RecordTypes\SupplierProductSeeder::specification(),
            'unit_of_measure' => \App\Database\Seeds\Cement\RecordTypes\UnitOfMeasureSeeder::specification(),
            'product_category' => \App\Database\Seeds\Cement\RecordTypes\ProductCategorySeeder::specification(),
            'product' => \App\Database\Seeds\Cement\RecordTypes\ProductSeeder::specification(),
            'price_list' => \App\Database\Seeds\Cement\RecordTypes\PriceListSeeder::specification(),
            'price_list_item' => \App\Database\Seeds\Cement\RecordTypes\PriceListItemSeeder::specification(),
            'purchase' => \App\Database\Seeds\Cement\RecordTypes\PurchaseSeeder::specification(),
            'purchaseItem' => \App\Database\Seeds\Cement\RecordTypes\PurchaseItemSeeder::specification(),
            'cement_loading' => \App\Database\Seeds\Cement\RecordTypes\CementLoadingSeeder::specification(),
            'loading_clearance' => \App\Database\Seeds\Cement\RecordTypes\LoadingClearanceSeeder::specification(),
            'supplier_purchase_payment' => \App\Database\Seeds\Cement\RecordTypes\SupplierPurchasePaymentSeeder::specification(),
            'purchase_adjustment' => \App\Database\Seeds\Cement\RecordTypes\PurchaseAdjustmentSeeder::specification(),
            'customer_sales' => \App\Database\Seeds\Cement\RecordTypes\CustomerSalesSeeder::specification(),
            'customer_sale_item' => \App\Database\Seeds\Cement\RecordTypes\CustomerSaleItemSeeder::specification(),
            'customer_payment' => \App\Database\Seeds\Cement\RecordTypes\CustomerPaymentSeeder::specification(),
            'customer_sale_return' => \App\Database\Seeds\Cement\RecordTypes\CustomerSaleReturnSeeder::specification(),
            'delivery_proof' => \App\Database\Seeds\Cement\RecordTypes\DeliveryProofSeeder::specification(),
            'inventory_location' => \App\Database\Seeds\Cement\RecordTypes\InventoryLocationSeeder::specification(),
            'inventory_stock' => \App\Database\Seeds\Cement\RecordTypes\InventoryStockSeeder::specification(),
            'inventory_movement' => \App\Database\Seeds\Cement\RecordTypes\InventoryMovementSeeder::specification(),
            'inventory_cost_layer' => \App\Database\Seeds\Cement\RecordTypes\InventoryCostLayerSeeder::specification(),
            'inventory_stocktake' => \App\Database\Seeds\Cement\RecordTypes\InventoryStocktakeSeeder::specification(),
            'inventory_stocktake_line' => \App\Database\Seeds\Cement\RecordTypes\InventoryStocktakeLineSeeder::specification(),
            'stock_adjustment' => \App\Database\Seeds\Cement\RecordTypes\StockAdjustmentSeeder::specification(),
            'damaged_goods' => \App\Database\Seeds\Cement\RecordTypes\DamagedGoodsSeeder::specification(),
            'inventory_transfer' => \App\Database\Seeds\Cement\RecordTypes\InventoryTransferSeeder::specification(),
            'vehicle' => \App\Database\Seeds\Cement\RecordTypes\VehicleSeeder::specification(),
            'trip' => \App\Database\Seeds\Cement\RecordTypes\TripSeeder::specification(),
            'trip_destination' => \App\Database\Seeds\Cement\RecordTypes\TripDestinationSeeder::specification(),
            'fuel_transaction' => \App\Database\Seeds\Cement\RecordTypes\FuelTransactionSeeder::specification(),
            'vehicle_maintenance' => \App\Database\Seeds\Cement\RecordTypes\VehicleMaintenanceSeeder::specification(),
            'trip_expense' => \App\Database\Seeds\Cement\RecordTypes\TripExpenseSeeder::specification(),
            'supplier_incentive_scheme' => \App\Database\Seeds\Cement\RecordTypes\SupplierIncentiveSchemeSeeder::specification(),
            'supplier_incentive' => \App\Database\Seeds\Cement\RecordTypes\SupplierIncentiveSeeder::specification(),
            'supplier_incentive_receipt' => \App\Database\Seeds\Cement\RecordTypes\SupplierIncentiveReceiptSeeder::specification(),
            'staff_employment' => \App\Database\Seeds\Cement\RecordTypes\StaffEmploymentSeeder::specification(),
            'payroll' => \App\Database\Seeds\Cement\RecordTypes\PayrollSeeder::specification(),
            'payroll_item' => \App\Database\Seeds\Cement\RecordTypes\PayrollItemSeeder::specification(),
            'payroll_payment' => \App\Database\Seeds\Cement\RecordTypes\PayrollPaymentSeeder::specification(),
            'staff_deduction' => \App\Database\Seeds\Cement\RecordTypes\StaffDeductionSeeder::specification(),
            'expense' => \App\Database\Seeds\Cement\RecordTypes\ExpenseSeeder::specification(),
            'report' => \App\Database\Seeds\Cement\RecordTypes\ReportSeeder::specification(),
            'report_result' => \App\Database\Seeds\Cement\RecordTypes\ReportResultSeeder::specification(),
            'report_delivery' => \App\Database\Seeds\Cement\RecordTypes\ReportDeliverySeeder::specification(),
            'report_schedule' => \App\Database\Seeds\Cement\RecordTypes\ReportScheduleSeeder::specification(),
            'cement_branch' => \App\Database\Seeds\Cement\RecordTypes\CementBranchSeeder::specification(),
            'cement_audit_event' => \App\Database\Seeds\Cement\RecordTypes\CementAuditEventSeeder::specification(),
        ];
    }

    public static function serviceRegistrations(): array
    {
        return [
            'CementPurchasePostingService' => \App\Database\Seeds\Cement\Services\CementPurchasePostingServiceSeeder::specification(),
            'CementPurchaseItemLockService' => \App\Database\Seeds\Cement\Services\CementPurchaseItemLockServiceSeeder::specification(),
            'CementLoadingAllocationService' => \App\Database\Seeds\Cement\Services\CementLoadingAllocationServiceSeeder::specification(),
            'CementLoadingClearingService' => \App\Database\Seeds\Cement\Services\CementLoadingClearingServiceSeeder::specification(),
            'CementPurchaseQuantityRollupService' => \App\Database\Seeds\Cement\Services\CementPurchaseQuantityRollupServiceSeeder::specification(),
            'CementSalesPricingService' => \App\Database\Seeds\Cement\Services\CementSalesPricingServiceSeeder::specification(),
            'CementSalesPostingService' => \App\Database\Seeds\Cement\Services\CementSalesPostingServiceSeeder::specification(),
            'CementPaymentPostingService' => \App\Database\Seeds\Cement\Services\CementPaymentPostingServiceSeeder::specification(),
            'CementInventoryMovementService' => \App\Database\Seeds\Cement\Services\CementInventoryMovementServiceSeeder::specification(),
            'CementInventoryValuationService' => \App\Database\Seeds\Cement\Services\CementInventoryValuationServiceSeeder::specification(),
            'CementStocktakePostingService' => \App\Database\Seeds\Cement\Services\CementStocktakePostingServiceSeeder::specification(),
            'CementStockAdjustmentService' => \App\Database\Seeds\Cement\Services\CementStockAdjustmentServiceSeeder::specification(),
            'CementInventoryTransferService' => \App\Database\Seeds\Cement\Services\CementInventoryTransferServiceSeeder::specification(),
            'CementSalesReturnService' => \App\Database\Seeds\Cement\Services\CementSalesReturnServiceSeeder::specification(),
            'CementDeliveryAcceptanceService' => \App\Database\Seeds\Cement\Services\CementDeliveryAcceptanceServiceSeeder::specification(),
            'CementTripCostAllocationService' => \App\Database\Seeds\Cement\Services\CementTripCostAllocationServiceSeeder::specification(),
            'CementFuelPostingService' => \App\Database\Seeds\Cement\Services\CementFuelPostingServiceSeeder::specification(),
            'CementMaintenancePostingService' => \App\Database\Seeds\Cement\Services\CementMaintenancePostingServiceSeeder::specification(),
            'CementTripExpensePostingService' => \App\Database\Seeds\Cement\Services\CementTripExpensePostingServiceSeeder::specification(),
            'CementIncentiveAccrualService' => \App\Database\Seeds\Cement\Services\CementIncentiveAccrualServiceSeeder::specification(),
            'CementIncentiveReceiptService' => \App\Database\Seeds\Cement\Services\CementIncentiveReceiptServiceSeeder::specification(),
            'CementPayrollPostingService' => \App\Database\Seeds\Cement\Services\CementPayrollPostingServiceSeeder::specification(),
            'CementPayrollPaymentService' => \App\Database\Seeds\Cement\Services\CementPayrollPaymentServiceSeeder::specification(),
            'CementExpensePostingService' => \App\Database\Seeds\Cement\Services\CementExpensePostingServiceSeeder::specification(),
            'ReportGenerationService' => \App\Database\Seeds\Cement\Services\ReportGenerationServiceSeeder::specification(),
            'ReportExporterService' => \App\Database\Seeds\Cement\Services\ReportExporterServiceSeeder::specification(),
            'ReportEmailService' => \App\Database\Seeds\Cement\Services\ReportEmailServiceSeeder::specification(),
            'ReportScheduleService' => \App\Database\Seeds\Cement\Services\ReportScheduleServiceSeeder::specification(),
        ];
    }

    public static function routes(): array
    {
        return [
            ...\App\Database\Seeds\Cement\Routes\CementMasterRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementPricingRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementProcurementRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementSalesRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementInventoryRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementLogisticsRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementIncentivesRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementPeopleRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementFinanceRoutesSeeder::routes(),
            ...\App\Database\Seeds\Cement\Routes\CementAdminRoutesSeeder::routes(),
        ];
    }

    public static function portals(): array
    {
        return [
            \App\Database\Seeds\Cement\Portals\CementSystemAdminPortalSeeder::specification(),
            \App\Database\Seeds\Cement\Portals\CementAdminPortalSeeder::specification(),
            \App\Database\Seeds\Cement\Portals\CementAccountantPortalSeeder::specification(),
            \App\Database\Seeds\Cement\Portals\CementSalesManagerPortalSeeder::specification(),
            \App\Database\Seeds\Cement\Portals\CementStoreKeeperPortalSeeder::specification(),
            \App\Database\Seeds\Cement\Portals\CementDataEntryPortalSeeder::specification(),
            \App\Database\Seeds\Cement\Portals\CementDriverPortalSeeder::specification(),
        ];
    }

}
