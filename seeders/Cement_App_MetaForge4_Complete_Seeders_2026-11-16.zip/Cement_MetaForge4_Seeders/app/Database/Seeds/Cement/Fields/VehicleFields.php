<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class VehicleFields
{
    public const CODE = 'code';
    public const REGISTRATION_NUMBER = 'registrationNumber';
    public const VEHICLE_TYPE = 'vehicleType';
    public const MAKE = 'make';
    public const MODEL = 'model';
    public const CAPACITY_TONNES = 'capacityTonnes';
    public const CAPACITY_BAGS = 'capacityBags';
    public const OWNER_TYPE = 'ownerType';
    public const OWNER_NAME = 'ownerName';
    public const INSURANCE_EXPIRY = 'insuranceExpiry';
    public const ROADWORTHINESS_EXPIRY = 'roadworthinessExpiry';
    public const ODOMETER = 'odometer';
    public const STATUS = 'status';
}
