<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class StaffEmploymentFields
{
    public const CODE = 'code';
    public const PERSON_ID = 'personId';
    public const EMPLOYEE_NUMBER = 'employeeNumber';
    public const DEPARTMENT = 'department';
    public const DESIGNATION = 'designation';
    public const HIRE_DATE = 'hireDate';
    public const TERMINATION_DATE = 'terminationDate';
    public const MANAGER_EMPLOYMENT_ID = 'managerEmploymentId';
    public const EMPLOYMENT_TYPE = 'employmentType';
    public const BASIC_SALARY = 'basicSalary';
    public const DEFAULT_BANK_ACCOUNT = 'defaultBankAccount';
    public const PAYROLL_ACCOUNT_ID = 'payrollAccountId';
    public const COOPERATIVE_MEMBER_ID = 'cooperativeMemberId';
    public const DEFAULT_SAVINGS_ACCOUNT_ID = 'defaultSavingsAccountId';
    public const DEFAULT_LOAN_ACCOUNT_ID = 'defaultLoanAccountId';
    public const STATUS = 'status';
}
