<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CustomerSaleReturnFields
{
    public const CODE = 'code';
    public const SALE_ID = 'saleId';
    public const SALE_ITEM_ID = 'saleItemId';
    public const QUANTITY = 'quantity';
    public const UNIT_ID = 'unitId';
    public const RETURN_REASON = 'returnReason';
    public const DISPOSITION = 'disposition';
    public const STOCK_MOVEMENT_ID = 'stockMovementId';
    public const REFUND_AMOUNT = 'refundAmount';
    public const APPROVED_BY = 'approvedBy';
    public const STATUS = 'status';
}
