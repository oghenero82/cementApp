<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryLocationFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const LOCATION_TYPE = 'locationType';
    public const PARENT_LOCATION_ID = 'parentLocationId';
    public const ADDRESS = 'address';
    public const BRANCH_CODE = 'branchCode';
    public const IS_QUARANTINE = 'isQuarantine';
    public const STATUS = 'status';
}
