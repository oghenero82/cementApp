<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CustomerFields
{
    public const CODE = 'code';
    public const PERSON_ID = 'personId';
    public const COMPANY_NAME = 'companyName';
    public const CUSTOMER_TYPE = 'customerType';
    public const CONTACT_PERSON_ID = 'contactPersonId';
    public const PHONE = 'phone';
    public const EMAIL = 'email';
    public const BILLING_ADDRESS = 'billingAddress';
    public const DELIVERY_ADDRESSES = 'deliveryAddresses';
    public const CREDIT_LIMIT = 'creditLimit';
    public const PAYMENT_TERMS_DAYS = 'paymentTermsDays';
    public const DEFAULT_PRICE_LIST_ID = 'defaultPriceListId';
    public const ACCOUNT_ID = 'accountId';
    public const TAX_NUMBER = 'taxNumber';
    public const STATUS = 'status';
}
