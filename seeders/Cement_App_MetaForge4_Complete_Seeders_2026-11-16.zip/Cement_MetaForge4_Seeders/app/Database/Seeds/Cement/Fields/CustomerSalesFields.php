<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CustomerSalesFields
{
    public const CODE = 'code';
    public const CUSTOMER_ID = 'customerId';
    public const SALE_DATE = 'saleDate';
    public const SOURCE_LOADING_ID = 'sourceLoadingId';
    public const SOURCE_TRIP_ID = 'sourceTripId';
    public const WAREHOUSE_ID = 'warehouseId';
    public const PRICE_LIST_ID = 'priceListId';
    public const CURRENCY = 'currency';
    public const GROSS_AMOUNT = 'grossAmount';
    public const DISCOUNT_AMOUNT = 'discountAmount';
    public const TAX_AMOUNT = 'taxAmount';
    public const NET_AMOUNT = 'netAmount';
    public const AMOUNT_PAID = 'amountPaid';
    public const BALANCE_DUE = 'balanceDue';
    public const PAYMENT_TERMS_DAYS = 'paymentTermsDays';
    public const OWNERSHIP_TRANSFER_POLICY = 'ownershipTransferPolicy';
    public const DELIVERED_AT = 'deliveredAt';
    public const DELIVERY_STATUS = 'deliveryStatus';
    public const STATUS = 'status';
}
