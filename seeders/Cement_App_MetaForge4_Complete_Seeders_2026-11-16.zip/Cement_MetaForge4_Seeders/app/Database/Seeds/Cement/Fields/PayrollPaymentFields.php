<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PayrollPaymentFields
{
    public const CODE = 'code';
    public const PAYROLL_ITEM_ID = 'payrollItemId';
    public const EMPLOYMENT_ID = 'employmentId';
    public const PAID_DATE = 'paidDate';
    public const PAYMENT_METHOD = 'paymentMethod';
    public const BANK_ACCOUNT = 'bankAccount';
    public const PAYMENT_ACCOUNT_ID = 'paymentAccountId';
    public const AMOUNT = 'amount';
    public const TRANSFER_REFERENCE = 'transferReference';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
