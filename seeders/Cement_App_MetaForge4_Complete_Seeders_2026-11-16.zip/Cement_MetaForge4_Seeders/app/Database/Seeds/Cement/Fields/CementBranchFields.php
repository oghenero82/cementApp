<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CementBranchFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const ADDRESS = 'address';
    public const DEFAULT_DEPOT_ID = 'defaultDepotId';
    public const DEFAULT_WAREHOUSE_ID = 'defaultWarehouseId';
    public const DEFAULT_BANK_ACCOUNT_ID = 'defaultBankAccountId';
    public const MANAGER_ID = 'managerId';
    public const STATUS = 'status';
}
