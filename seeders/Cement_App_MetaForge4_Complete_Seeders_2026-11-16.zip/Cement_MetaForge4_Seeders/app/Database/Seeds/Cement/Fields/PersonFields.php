<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PersonFields
{
    public const CODE = 'code';
    public const FIRST_NAME = 'firstName';
    public const MIDDLE_NAME = 'middleName';
    public const LAST_NAME = 'lastName';
    public const PHONE = 'phone';
    public const EMAIL = 'email';
    public const ADDRESS = 'address';
    public const DATE_OF_BIRTH = 'dateOfBirth';
    public const IDENTIFICATION = 'identification';
    public const STATUS = 'status';
}
