<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryMovementFields
{
    public const CODE = 'code';
    public const MOVEMENT_DATE = 'movementDate';
    public const MOVEMENT_TYPE = 'movementType';
    public const PRODUCT_ID = 'productId';
    public const SOURCE_LOCATION_ID = 'sourceLocationId';
    public const DESTINATION_LOCATION_ID = 'destinationLocationId';
    public const STOCK_CONDITION = 'stockCondition';
    public const QTY_BASE = 'qtyBase';
    public const UNIT_ID = 'unitId';
    public const UNIT_CONVERSION_SNAPSHOT = 'unitConversionSnapshot';
    public const COST_POLICY = 'costPolicy';
    public const UNIT_COST = 'unitCost';
    public const TOTAL_COST = 'totalCost';
    public const SOURCE_RECORD_TYPE_CODE = 'sourceRecordTypeCode';
    public const SOURCE_RECORD_ID = 'sourceRecordId';
    public const PURCHASE_ITEM_ID = 'purchaseItemId';
    public const LOADING_ID = 'loadingId';
    public const SALE_ITEM_ID = 'saleItemId';
    public const FIFO_ALLOCATIONS = 'fifoAllocations';
    public const AUTHORIZED_BY = 'authorizedBy';
    public const EFFECTIVE_AT = 'effectiveAt';
    public const STATUS = 'status';
}
