<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class StockAdjustmentFields
{
    public const CODE = 'code';
    public const LOCATION_ID = 'locationId';
    public const PRODUCT_ID = 'productId';
    public const ADJUSTMENT_DATE = 'adjustmentDate';
    public const REASON_CODE = 'reasonCode';
    public const STOCK_CONDITION = 'stockCondition';
    public const QUANTITY_DELTA = 'quantityDelta';
    public const UNIT_COST = 'unitCost';
    public const AMOUNT = 'amount';
    public const STOCKTAKE_LINE_ID = 'stocktakeLineId';
    public const SOURCE_MOVEMENT_ID = 'sourceMovementId';
    public const APPROVED_BY = 'approvedBy';
    public const APPROVAL_DATE = 'approvalDate';
    public const STATUS = 'status';
}
