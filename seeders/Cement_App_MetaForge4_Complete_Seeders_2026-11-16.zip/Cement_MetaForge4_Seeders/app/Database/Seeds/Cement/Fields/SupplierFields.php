<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const SUPPLIER_NUMBER = 'supplierNumber';
    public const CONTACT_PERSON_ID = 'contactPersonId';
    public const PHONE = 'phone';
    public const EMAIL = 'email';
    public const ADDRESS = 'address';
    public const BANK_ACCOUNTS = 'bankAccounts';
    public const CREDIT_TERMS_DAYS = 'creditTermsDays';
    public const CONTROL_ACCOUNT_ID = 'controlAccountId';
    public const PREPAID_ACCOUNT_ID = 'prepaidAccountId';
    public const TAX_NUMBER = 'taxNumber';
    public const STATUS = 'status';
}
