<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PayrollItemFields
{
    public const CODE = 'code';
    public const PAYROLL_ID = 'payrollId';
    public const EMPLOYMENT_ID = 'employmentId';
    public const BASIC_SALARY = 'basicSalary';
    public const ALLOWANCES = 'allowances';
    public const OTHER_EARNINGS = 'otherEarnings';
    public const GROSS_PAY = 'grossPay';
    public const TAX_AMOUNT = 'taxAmount';
    public const PENSION_AMOUNT = 'pensionAmount';
    public const DEDUCTIONS = 'deductions';
    public const SAVINGS_DEDUCTION = 'savingsDeduction';
    public const LOAN_DEDUCTION = 'loanDeduction';
    public const NET_PAY = 'netPay';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
