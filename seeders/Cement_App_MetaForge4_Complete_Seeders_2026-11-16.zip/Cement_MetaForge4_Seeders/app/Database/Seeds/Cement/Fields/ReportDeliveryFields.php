<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ReportDeliveryFields
{
    public const CODE = 'code';
    public const REPORT_RESULT_ID = 'reportResultId';
    public const DELIVERY_METHOD = 'deliveryMethod';
    public const RECIPIENT = 'recipient';
    public const DELIVERED_AT = 'deliveredAt';
    public const DELIVERY_STATUS = 'deliveryStatus';
    public const FAILURE_REASON = 'failureReason';
    public const RETRY_COUNT = 'retryCount';
    public const STATUS = 'status';
}
