<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CustomerSaleItemFields
{
    public const CODE = 'code';
    public const SALE_ID = 'saleId';
    public const PRODUCT_ID = 'productId';
    public const UNIT_ID = 'unitId';
    public const QUANTITY = 'quantity';
    public const QUANTITY_BASE = 'quantityBase';
    public const LISTED_UNIT_PRICE = 'listedUnitPrice';
    public const AGREED_UNIT_PRICE = 'agreedUnitPrice';
    public const DISCOUNT_TYPE = 'discountType';
    public const DISCOUNT_VALUE = 'discountValue';
    public const NET_UNIT_PRICE = 'netUnitPrice';
    public const TAX_RATE = 'taxRate';
    public const TAX_AMOUNT = 'taxAmount';
    public const LINE_AMOUNT = 'lineAmount';
    public const PRICE_LIST_ITEM_ID = 'priceListItemId';
    public const SOURCE_PURCHASE_ITEM_ID = 'sourcePurchaseItemId';
    public const SOURCE_LOADING_ID = 'sourceLoadingId';
    public const SOURCE_MOVEMENT_ID = 'sourceMovementId';
    public const UNIT_CONVERSION_SNAPSHOT = 'unitConversionSnapshot';
    public const STATUS = 'status';
}
