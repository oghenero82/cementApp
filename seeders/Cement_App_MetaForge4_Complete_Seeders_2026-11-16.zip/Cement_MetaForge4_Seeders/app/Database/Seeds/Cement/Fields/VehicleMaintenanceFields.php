<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class VehicleMaintenanceFields
{
    public const CODE = 'code';
    public const VEHICLE_ID = 'vehicleId';
    public const TRIP_ID = 'tripId';
    public const SERVICE_DATE = 'serviceDate';
    public const MAINTENANCE_TYPE = 'maintenanceType';
    public const DESCRIPTION = 'description';
    public const SERVICE_PROVIDER = 'serviceProvider';
    public const ODOMETER = 'odometer';
    public const PARTS_COST = 'partsCost';
    public const LABOR_COST = 'laborCost';
    public const TOTAL_COST = 'totalCost';
    public const PAYMENT_ACCOUNT_ID = 'paymentAccountId';
    public const NEXT_SERVICE_DATE = 'nextServiceDate';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
