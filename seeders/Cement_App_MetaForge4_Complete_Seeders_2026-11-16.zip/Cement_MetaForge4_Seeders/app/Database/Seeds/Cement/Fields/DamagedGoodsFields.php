<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class DamagedGoodsFields
{
    public const CODE = 'code';
    public const LOCATION_ID = 'locationId';
    public const PRODUCT_ID = 'productId';
    public const RELATED_MOVEMENT_ID = 'relatedMovementId';
    public const QUANTITY = 'quantity';
    public const REASON = 'reason';
    public const SEVERITY = 'severity';
    public const CONDITION = 'condition';
    public const PHOTO_EVIDENCE = 'photoEvidence';
    public const DECISION = 'decision';
    public const APPROVED_BY = 'approvedBy';
    public const WRITE_OFF_ADJUSTMENT_ID = 'writeOffAdjustmentId';
    public const STATUS = 'status';
}
