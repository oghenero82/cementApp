<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class TripFields
{
    public const CODE = 'code';
    public const VEHICLE_ID = 'vehicleId';
    public const DRIVER_ID = 'driverId';
    public const LOADING_ID = 'loadingId';
    public const ORIGIN_DEPOT_ID = 'originDepotId';
    public const ORIGIN_LOCATION_ID = 'originLocationId';
    public const DEPARTURE_AT = 'departureAt';
    public const ARRIVAL_AT = 'arrivalAt';
    public const SCHEDULED_DATE = 'scheduledDate';
    public const DESTINATION_COUNT = 'destinationCount';
    public const TOTAL_QUANTITY = 'totalQuantity';
    public const TOTAL_FUEL_COST = 'totalFuelCost';
    public const TOTAL_MAINTENANCE_COST = 'totalMaintenanceCost';
    public const TOTAL_TRIP_EXPENSE = 'totalTripExpense';
    public const TOTAL_TRIP_COST = 'totalTripCost';
    public const STATUS = 'status';
    public const NOTES = 'notes';
}
