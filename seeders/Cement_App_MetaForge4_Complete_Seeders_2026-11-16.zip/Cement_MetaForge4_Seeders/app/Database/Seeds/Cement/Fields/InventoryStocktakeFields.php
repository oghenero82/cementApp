<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryStocktakeFields
{
    public const CODE = 'code';
    public const LOCATION_ID = 'locationId';
    public const COUNT_DATE = 'countDate';
    public const INVENTORY_KEEPING_METHOD = 'inventoryKeepingMethod';
    public const REFERENCE = 'reference';
    public const COUNTED_BY = 'countedBy';
    public const VERIFIED_BY = 'verifiedBy';
    public const POSTED_BY = 'postedBy';
    public const STATUS = 'status';
}
