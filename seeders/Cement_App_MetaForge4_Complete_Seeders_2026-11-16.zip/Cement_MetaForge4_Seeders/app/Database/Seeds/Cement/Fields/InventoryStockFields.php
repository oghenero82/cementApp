<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryStockFields
{
    public const CODE = 'code';
    public const LOCATION_ID = 'locationId';
    public const PRODUCT_ID = 'productId';
    public const STOCK_CONDITION = 'stockCondition';
    public const QUANTITY_ON_HAND = 'quantityOnHand';
    public const QUANTITY_RESERVED = 'quantityReserved';
    public const QUANTITY_AVAILABLE = 'quantityAvailable';
    public const AVERAGE_UNIT_COST = 'averageUnitCost';
    public const TOTAL_VALUE = 'totalValue';
    public const LAST_MOVEMENT_AT = 'lastMovementAt';
    public const LAST_STOCKTAKE_AT = 'lastStocktakeAt';
    public const STATUS = 'status';
}
