<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryTransferFields
{
    public const CODE = 'code';
    public const SOURCE_LOCATION_ID = 'sourceLocationId';
    public const DESTINATION_LOCATION_ID = 'destinationLocationId';
    public const PRODUCT_ID = 'productId';
    public const QUANTITY = 'quantity';
    public const UNIT_ID = 'unitId';
    public const REQUEST_DATE = 'requestDate';
    public const DISPATCHED_AT = 'dispatchedAt';
    public const RECEIVED_AT = 'receivedAt';
    public const OUT_MOVEMENT_ID = 'outMovementId';
    public const IN_MOVEMENT_ID = 'inMovementId';
    public const APPROVED_BY = 'approvedBy';
    public const STATUS = 'status';
}
