<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class UnitOfMeasureFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const SYMBOL = 'symbol';
    public const DIMENSION = 'dimension';
    public const DECIMAL_PLACES = 'decimalPlaces';
    public const CONVERSION_BASE_FACTOR = 'conversionBaseFactor';
    public const STATUS = 'status';
}
