<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierPurchasePaymentFields
{
    public const CODE = 'code';
    public const PURCHASE_ID = 'purchaseId';
    public const AMOUNT = 'amount';
    public const PAID_AT = 'paidAt';
    public const PAYMENT_METHOD = 'paymentMethod';
    public const BANK_ACCOUNT_ID = 'bankAccountId';
    public const REFERENCE = 'reference';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
