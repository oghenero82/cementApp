<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PurchaseFields
{
    public const CODE = 'code';
    public const SUPPLIER_ID = 'supplierId';
    public const SUPPLIER_DEPOT_ID = 'supplierDepotId';
    public const PURCHASE_DATE = 'purchaseDate';
    public const SUPPLIER_ORDER_NO = 'supplierOrderNo';
    public const SUPPLIER_PIN = 'supplierPin';
    public const SUPPLIER_BIN = 'supplierBin';
    public const SUPPLIER_LOGIN_CODE = 'supplierLoginCode';
    public const CURRENCY = 'currency';
    public const EXCHANGE_RATE = 'exchangeRate';
    public const PAYMENT_ACCOUNT_ID = 'paymentAccountId';
    public const PREPAID_ACCOUNT_ID = 'prepaidAccountId';
    public const GROSS_AMOUNT = 'grossAmount';
    public const DISCOUNT_AMOUNT = 'discountAmount';
    public const NET_AMOUNT = 'netAmount';
    public const PAID_AMOUNT = 'paidAmount';
    public const OWNERSHIP_TRANSFER_POLICY = 'ownershipTransferPolicy';
    public const STATUS = 'status';
    public const NOTES = 'notes';
}
