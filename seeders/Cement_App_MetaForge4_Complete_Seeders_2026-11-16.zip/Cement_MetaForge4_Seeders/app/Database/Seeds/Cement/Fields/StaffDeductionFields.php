<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class StaffDeductionFields
{
    public const CODE = 'code';
    public const EMPLOYMENT_ID = 'employmentId';
    public const DEDUCTION_TYPE = 'deductionType';
    public const SAVINGS_ACCOUNT_ID = 'savingsAccountId';
    public const LOAN_ACCOUNT_ID = 'loanAccountId';
    public const FIXED_AMOUNT = 'fixedAmount';
    public const RATE = 'rate';
    public const START_DATE = 'startDate';
    public const END_DATE = 'endDate';
    public const CURRENT_BALANCE = 'currentBalance';
    public const STATUS = 'status';
}
