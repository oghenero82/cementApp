<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ExpenseFields
{
    public const CODE = 'code';
    public const EXPENSE_DATE = 'expenseDate';
    public const EXPENSE_TYPE = 'expenseType';
    public const DESCRIPTION = 'description';
    public const AMOUNT = 'amount';
    public const TAX_AMOUNT = 'taxAmount';
    public const SUPPLIER_ID = 'supplierId';
    public const VEHICLE_ID = 'vehicleId';
    public const TRIP_ID = 'tripId';
    public const EMPLOYEE_ID = 'employeeId';
    public const PAYMENT_ACCOUNT_ID = 'paymentAccountId';
    public const EXPENSE_ACCOUNT_ID = 'expenseAccountId';
    public const REFERENCE = 'reference';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
