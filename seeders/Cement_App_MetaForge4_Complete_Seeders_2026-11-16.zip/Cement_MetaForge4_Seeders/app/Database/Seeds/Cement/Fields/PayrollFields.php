<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PayrollFields
{
    public const CODE = 'code';
    public const PERIOD_START = 'periodStart';
    public const PERIOD_END = 'periodEnd';
    public const PAYMENT_DATE = 'paymentDate';
    public const TOTAL_GROSS = 'totalGross';
    public const TOTAL_DEDUCTIONS = 'totalDeductions';
    public const TOTAL_NET = 'totalNet';
    public const CURRENCY = 'currency';
    public const APPROVED_BY = 'approvedBy';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
