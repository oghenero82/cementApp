<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class DeliveryProofFields
{
    public const CODE = 'code';
    public const SALE_ID = 'saleId';
    public const TRIP_DESTINATION_ID = 'tripDestinationId';
    public const DELIVERED_DATE = 'deliveredDate';
    public const ACCEPTED_QUANTITY = 'acceptedQuantity';
    public const REJECTED_QUANTITY = 'rejectedQuantity';
    public const SIGNATURE = 'signature';
    public const PHOTOS = 'photos';
    public const RECEIVER_NAME = 'receiverName';
    public const RECEIVER_PHONE = 'receiverPhone';
    public const DELIVERY_NOTE_NO = 'deliveryNoteNo';
    public const STATUS = 'status';
}
