<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierProductFields
{
    public const CODE = 'code';
    public const SUPPLIER_ID = 'supplierId';
    public const PRODUCT_ID = 'productId';
    public const SUPPLIER_PRODUCT_CODE = 'supplierProductCode';
    public const PRODUCT_NAME_AT_SUPPLIER = 'productNameAtSupplier';
    public const DEPOT_IDS = 'depotIds';
    public const MIN_ORDER_QUANTITY = 'minOrderQuantity';
    public const ACTIVE = 'active';
    public const STATUS = 'status';
}
