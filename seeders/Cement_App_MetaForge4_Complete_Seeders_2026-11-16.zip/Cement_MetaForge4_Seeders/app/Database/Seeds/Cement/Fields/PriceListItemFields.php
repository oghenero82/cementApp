<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PriceListItemFields
{
    public const CODE = 'code';
    public const PRICE_LIST_ID = 'priceListId';
    public const PRODUCT_ID = 'productId';
    public const UNIT_ID = 'unitId';
    public const MIN_QUANTITY = 'minQuantity';
    public const MAX_QUANTITY = 'maxQuantity';
    public const UNIT_PRICE = 'unitPrice';
    public const VALID_FROM = 'validFrom';
    public const VALID_TO = 'validTo';
    public const CUSTOMER_ID = 'customerId';
    public const PRIORITY = 'priority';
    public const STATUS = 'status';
}
