<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CustomerPaymentFields
{
    public const CODE = 'code';
    public const CUSTOMER_ID = 'customerId';
    public const SALE_ID = 'saleId';
    public const AMOUNT = 'amount';
    public const PAYMENT_DATE = 'paymentDate';
    public const PAYMENT_METHOD = 'paymentMethod';
    public const BANK_ACCOUNT_ID = 'bankAccountId';
    public const REFERENCE = 'reference';
    public const POSTED_JOURNAL_ID = 'postedJournalId';
    public const STATUS = 'status';
}
