<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ProductFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const CATEGORY_ID = 'categoryId';
    public const BRAND = 'brand';
    public const GRADE = 'grade';
    public const DESCRIPTION = 'description';
    public const BASE_UNIT_ID = 'baseUnitId';
    public const PACKAGE_UNIT_ID = 'packageUnitId';
    public const PACKAGE_SIZE = 'packageSize';
    public const PACKAGE_WEIGHT_KG = 'packageWeightKg';
    public const UNITS_PER_BAG = 'unitsPerBag';
    public const BAGS_PER_PALLET = 'bagsPerPallet';
    public const TRACKING_MODE = 'trackingMode';
    public const INVENTORY_TRACKED = 'inventoryTracked';
    public const TAXABLE = 'taxable';
    public const STATUS = 'status';
}
