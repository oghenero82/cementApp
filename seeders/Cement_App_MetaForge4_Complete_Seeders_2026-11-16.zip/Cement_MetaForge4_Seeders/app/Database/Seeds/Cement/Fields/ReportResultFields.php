<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ReportResultFields
{
    public const CODE = 'code';
    public const REPORT_ID = 'reportId';
    public const GENERATED_AT = 'generatedAt';
    public const PERIOD_START = 'periodStart';
    public const PERIOD_END = 'periodEnd';
    public const PARAMETERS = 'parameters';
    public const TOTALS = 'totals';
    public const ROWS = 'rows';
    public const ARTIFACT_PATH = 'artifactPath';
    public const FILE_TYPE = 'fileType';
    public const GENERATED_BY = 'generatedBy';
    public const STATUS = 'status';
}
