<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierIncentiveFields
{
    public const CODE = 'code';
    public const SUPPLIER_ID = 'supplierId';
    public const SCHEME_ID = 'schemeId';
    public const PURCHASE_ID = 'purchaseId';
    public const LOADING_ID = 'loadingId';
    public const BENEFIT_DATE = 'benefitDate';
    public const BENEFIT_TYPE = 'benefitType';
    public const BASIS_QUANTITY = 'basisQuantity';
    public const BASIS_AMOUNT = 'basisAmount';
    public const RATE = 'rate';
    public const ACTUAL_AMOUNT = 'actualAmount';
    public const AMOUNT_RECEIVED = 'amountReceived';
    public const RECEIVABLE_ACCOUNT_ID = 'receivableAccountId';
    public const INCOME_ACCOUNT_ID = 'incomeAccountId';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
