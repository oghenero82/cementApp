<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ReportScheduleFields
{
    public const CODE = 'code';
    public const REPORT_ID = 'reportId';
    public const CADENCE = 'cadence';
    public const TIMEZONE = 'timezone';
    public const RECIPIENTS = 'recipients';
    public const OUTPUT_FORMAT = 'outputFormat';
    public const ENABLED = 'enabled';
    public const LAST_RUN_AT = 'lastRunAt';
    public const NEXT_RUN_AT = 'nextRunAt';
    public const STATUS = 'status';
}
