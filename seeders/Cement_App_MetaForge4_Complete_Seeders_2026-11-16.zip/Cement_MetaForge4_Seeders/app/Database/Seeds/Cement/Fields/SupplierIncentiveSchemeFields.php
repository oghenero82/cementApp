<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierIncentiveSchemeFields
{
    public const CODE = 'code';
    public const SUPPLIER_ID = 'supplierId';
    public const NAME = 'name';
    public const BASIS = 'basis';
    public const CALCULATION_TYPE = 'calculationType';
    public const RATE = 'rate';
    public const FIXED_AMOUNT = 'fixedAmount';
    public const THRESHOLD_QTY = 'thresholdQty';
    public const THRESHOLD_AMOUNT = 'thresholdAmount';
    public const VALID_FROM = 'validFrom';
    public const VALID_TO = 'validTo';
    public const PRODUCT_IDS = 'productIds';
    public const DEPOT_IDS = 'depotIds';
    public const STATUS = 'status';
}
