<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class FuelTransactionFields
{
    public const CODE = 'code';
    public const VEHICLE_ID = 'vehicleId';
    public const TRIP_ID = 'tripId';
    public const STATION_NAME = 'stationName';
    public const FUEL_DATE = 'fuelDate';
    public const LITRES = 'litres';
    public const PRICE_PER_LITRE = 'pricePerLitre';
    public const TOTAL_AMOUNT = 'totalAmount';
    public const PAID_BY = 'paidBy';
    public const PAYMENT_ACCOUNT_ID = 'paymentAccountId';
    public const RECEIPT_NUMBER = 'receiptNumber';
    public const ODOMETER = 'odometer';
    public const POSTED_JOURNAL_ID = 'postedJournalId';
    public const STATUS = 'status';
}
