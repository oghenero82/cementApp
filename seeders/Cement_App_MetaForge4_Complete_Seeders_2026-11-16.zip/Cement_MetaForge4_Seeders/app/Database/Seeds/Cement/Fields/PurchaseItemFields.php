<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PurchaseItemFields
{
    public const CODE = 'code';
    public const PURCHASE_ID = 'purchaseId';
    public const SUPPLIER_PRODUCT_ID = 'supplierProductId';
    public const PRODUCT_ID = 'productId';
    public const UNIT_ID = 'unitId';
    public const ORIGINAL_QUANTITY = 'originalQuantity';
    public const QUANTITY_BASE = 'quantityBase';
    public const UNIT_CONVERSION_SNAPSHOT = 'unitConversionSnapshot';
    public const UNIT_PRICE = 'unitPrice';
    public const DISCOUNT_TYPE = 'discountType';
    public const DISCOUNT_VALUE = 'discountValue';
    public const NET_UNIT_COST = 'netUnitCost';
    public const AMOUNT = 'amount';
    public const LOADED_QTY = 'loadedQty';
    public const CLEARED_QTY = 'clearedQty';
    public const DELIVERED_QTY = 'deliveredQty';
    public const FULLY_DELIVERED = 'fullyDelivered';
    public const FIRST_LOADED_AT = 'firstLoadedAt';
    public const BATCH_REFERENCE = 'batchReference';
    public const STATUS = 'status';
}
