<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierDepotFields
{
    public const CODE = 'code';
    public const SUPPLIER_ID = 'supplierId';
    public const NAME = 'name';
    public const ADDRESS = 'address';
    public const REGION = 'region';
    public const CONTACT_PHONE = 'contactPhone';
    public const SUPPLIER_DEPOT_CODE = 'supplierDepotCode';
    public const LOADING_RULES = 'loadingRules';
    public const STATUS = 'status';
}
