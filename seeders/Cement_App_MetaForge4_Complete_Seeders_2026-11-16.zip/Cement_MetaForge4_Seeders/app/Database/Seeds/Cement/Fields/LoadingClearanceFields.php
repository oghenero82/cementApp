<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class LoadingClearanceFields
{
    public const CODE = 'code';
    public const PURCHASE_ITEM_ID = 'purchaseItemId';
    public const LOADING_ID = 'loadingId';
    public const SUPPLIER_CLEARING_REF = 'supplierClearingRef';
    public const CLEARANCE_DATE = 'clearanceDate';
    public const QUANTITY = 'quantity';
    public const SUPPLIER_DOCUMENT = 'supplierDocument';
    public const VERIFIED_BY = 'verifiedBy';
    public const STATUS = 'status';
}
