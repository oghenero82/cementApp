<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryStocktakeLineFields
{
    public const CODE = 'code';
    public const STOCKTAKE_ID = 'stocktakeId';
    public const PRODUCT_ID = 'productId';
    public const STOCK_CONDITION = 'stockCondition';
    public const SYSTEM_QTY = 'systemQty';
    public const COUNTED_QTY = 'countedQty';
    public const VARIANCE_QTY = 'varianceQty';
    public const UNIT_COST = 'unitCost';
    public const VARIANCE_VALUE = 'varianceValue';
    public const NOTES = 'notes';
    public const STATUS = 'status';
}
