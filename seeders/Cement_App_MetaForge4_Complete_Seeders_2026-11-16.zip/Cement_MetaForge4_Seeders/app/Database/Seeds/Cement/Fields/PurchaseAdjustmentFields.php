<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PurchaseAdjustmentFields
{
    public const CODE = 'code';
    public const PURCHASE_ID = 'purchaseId';
    public const PURCHASE_ITEM_ID = 'purchaseItemId';
    public const ADJUSTMENT_TYPE = 'adjustmentType';
    public const QUANTITY = 'quantity';
    public const AMOUNT = 'amount';
    public const REASON = 'reason';
    public const APPROVED_BY = 'approvedBy';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
