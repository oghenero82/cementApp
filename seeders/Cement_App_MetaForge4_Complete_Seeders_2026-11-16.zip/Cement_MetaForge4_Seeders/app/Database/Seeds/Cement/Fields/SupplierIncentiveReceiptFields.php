<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class SupplierIncentiveReceiptFields
{
    public const CODE = 'code';
    public const INCENTIVE_ID = 'incentiveId';
    public const AMOUNT = 'amount';
    public const RECEIVED_DATE = 'receivedDate';
    public const BANK_ACCOUNT_ID = 'bankAccountId';
    public const REFERENCE = 'reference';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
