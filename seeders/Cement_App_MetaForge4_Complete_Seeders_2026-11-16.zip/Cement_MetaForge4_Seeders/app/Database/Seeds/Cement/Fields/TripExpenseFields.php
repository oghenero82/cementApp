<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class TripExpenseFields
{
    public const CODE = 'code';
    public const TRIP_ID = 'tripId';
    public const TRIP_DESTINATION_ID = 'tripDestinationId';
    public const EXPENSE_TYPE = 'expenseType';
    public const EXPENSE_DATE = 'expenseDate';
    public const AMOUNT = 'amount';
    public const PAID_TO = 'paidTo';
    public const PAYMENT_ACCOUNT_ID = 'paymentAccountId';
    public const ACCOUNT_ID = 'accountId';
    public const REFERENCE = 'reference';
    public const ALLOCATED_TO_SALE_ID = 'allocatedToSaleId';
    public const JOURNAL_ID = 'journalId';
    public const STATUS = 'status';
}
