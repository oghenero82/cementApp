<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ReportFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const MODULE_CODE = 'moduleCode';
    public const GENERATION_MODE = 'generationMode';
    public const SOURCE_RECORD_TYPES = 'sourceRecordTypes';
    public const COLUMNS = 'columns';
    public const FILTERS = 'filters';
    public const GROUPINGS = 'groupings';
    public const CALCULATIONS = 'calculations';
    public const RENDERER = 'renderer';
    public const DEFAULT_PERIOD = 'defaultPeriod';
    public const OUTPUT_FORMATS = 'outputFormats';
    public const ACCESS_ROLES = 'accessRoles';
    public const SCHEDULE_CODE = 'scheduleCode';
    public const IS_ACTIVE = 'isActive';
    public const STATUS = 'status';
}
