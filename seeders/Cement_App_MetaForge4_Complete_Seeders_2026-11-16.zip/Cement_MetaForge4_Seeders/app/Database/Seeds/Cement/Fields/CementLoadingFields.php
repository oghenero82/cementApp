<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CementLoadingFields
{
    public const CODE = 'code';
    public const PURCHASE_ITEM_ID = 'purchaseItemId';
    public const SUPPLIER_DEPOT_ID = 'supplierDepotId';
    public const SUPPLIER_LOADING_NO = 'supplierLoadingNo';
    public const SUPPLIER_PIN = 'supplierPin';
    public const SUPPLIER_BIN = 'supplierBin';
    public const LOADING_DATE = 'loadingDate';
    public const TRUCK_ID = 'truckId';
    public const DRIVER_ID = 'driverId';
    public const QUANTITY = 'quantity';
    public const QUANTITY_BASE = 'quantityBase';
    public const UNIT_ID = 'unitId';
    public const UNIT_CONVERSION_SNAPSHOT = 'unitConversionSnapshot';
    public const CUSTOMER_QUANTITY = 'customerQuantity';
    public const WAREHOUSE_QUANTITY = 'warehouseQuantity';
    public const CLEARED_QUANTITY = 'clearedQuantity';
    public const DESTINATIONS = 'destinations';
    public const ALLOCATION_ROWS = 'allocationRows';
    public const TRIP_ID = 'tripId';
    public const CONFIRMED_BY = 'confirmedBy';
    public const CONFIRMED_AT = 'confirmedAt';
    public const STATUS = 'status';
    public const NOTES = 'notes';
}
