<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class InventoryCostLayerFields
{
    public const CODE = 'code';
    public const STOCK_ID = 'stockId';
    public const PRODUCT_ID = 'productId';
    public const LOCATION_ID = 'locationId';
    public const SOURCE_MOVEMENT_ID = 'sourceMovementId';
    public const RECEIPT_DATE = 'receiptDate';
    public const ORIGINAL_QTY = 'originalQty';
    public const REMAINING_QTY = 'remainingQty';
    public const UNIT_COST = 'unitCost';
    public const STATUS = 'status';
}
