<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class CementAuditEventFields
{
    public const CODE = 'code';
    public const EVENT_TYPE = 'eventType';
    public const SOURCE_RECORD_TYPE_CODE = 'sourceRecordTypeCode';
    public const SOURCE_RECORD_ID = 'sourceRecordId';
    public const ACTOR_ID = 'actorId';
    public const MUTATION_ID = 'mutationId';
    public const REQUEST_ID = 'requestId';
    public const EVENT_DATE = 'eventDate';
    public const BEFORE_STATE = 'beforeState';
    public const AFTER_STATE = 'afterState';
    public const DESCRIPTION = 'description';
    public const STATUS = 'status';
}
