<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class PriceListFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const PRICE_TYPE = 'priceType';
    public const CURRENCY = 'currency';
    public const VALID_FROM = 'validFrom';
    public const VALID_TO = 'validTo';
    public const CUSTOMER_ID = 'customerId';
    public const PRIORITY = 'priority';
    public const TAX_INCLUSIVE = 'taxInclusive';
    public const STATUS = 'status';
}
