<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class TripDestinationFields
{
    public const CODE = 'code';
    public const TRIP_ID = 'tripId';
    public const DESTINATION_ORDER = 'destinationOrder';
    public const CUSTOMER_ID = 'customerId';
    public const DELIVERY_ADDRESS = 'deliveryAddress';
    public const SALE_ID = 'saleId';
    public const LOADING_ID = 'loadingId';
    public const PRODUCT_ID = 'productId';
    public const QUANTITY = 'quantity';
    public const UNIT_ID = 'unitId';
    public const ARRIVAL_AT = 'arrivalAt';
    public const DELIVERED_AT = 'deliveredAt';
    public const PROOF_ID = 'proofId';
    public const DELIVERY_STATUS = 'deliveryStatus';
    public const NOTES = 'notes';
    public const STATUS = 'status';
}
