<?php

declare(strict_types=1);

namespace App\Database\Seeds\Cement\Fields;

/** Stable MetaForge mutation & sync field-code registry. */
final class ProductCategoryFields
{
    public const CODE = 'code';
    public const NAME = 'name';
    public const PARENT_CATEGORY_ID = 'parentCategoryId';
    public const DESCRIPTION = 'description';
    public const STATUS = 'status';
}
