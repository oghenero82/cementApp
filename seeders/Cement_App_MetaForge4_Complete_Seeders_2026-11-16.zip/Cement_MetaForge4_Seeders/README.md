# Cement App — MetaForge 4 CI4 Seeder Package

**Version:** 2026-11-16  
**Target:** CodeIgniter 4; MetaForge 4 authoritative metadata in `mf_system`  
**Entrypoint:** `app/Database/Seeds/CementAppSeeder.php`  
**Design:** one cumulative package; no extra Cement-only Product/Account/Loan repositories; all tenant business rows continue through MetaForge's normal Mutation/Sync/Auth APIs.

## Package inventory

- 51 root RecordType *declaration and seeder classes* in `RecordTypes/` (each has a stable ordered `fields[]`).
- 51 matching PHP field-code registries in `Fields/`, plus a generated browser registry (`resources/cement/cement-field-codes.js`).
- 10 modular seeder classes in `Modules/`.
- 10 module route seeder classes with 4 normal route actions per RecordType plus dashboards, importer and reports.
- 7 portal seeder classes for System Admin, Admin, Accountant, Sales Manager, Store Keeper, Data Entry and Driver.
- 28 service *registration metadata classes*, **not** their runtime PHP handlers.
- 20 report template definitions for operational, inventory, staff and finance reporting.
- Idempotent `CementCatalogApplier`, canonical `CementMetadataBuilder`, role templates and institution-settings contract.
- `resources/cement/` JSON manifests for catalog inspection or authorized browser importer.

## Install in your MetaForge CI4 backend

1. **Back up your MetaForge database.** Copy the `app` folder into your MetaForge CI4 application's `app` folder. Preserve the exact namespaces and paths.
2. Ensure MetaForge system bootstrap and institution physical-table provisioning are already installed. This package does **not** create `mf_system`, physical tenant tables or the developer/institution credentials.
3. **Update the MetaForge RecordType root schema to the locked 2026-11-14 contract** before applying. The installer validates the root metadata and *refuses* to drop features silently. It requires: `fields`, `services`, `relatedActions`, `validation`, `lookups`, `searchColumnsMapping`, `uniques`, `lifecycle`, `ptableId`, and `moduleid`.
4. Set environment variable `CEMENT_RECORD_PHYSICAL_TABLE_CODE` to the actual **institution-scoped** `physical_table` code already provisioned in your installation (not `mf_system`). For example, use `<your-existing-tenant-table-code>`; no default value is assumed.
5. Run a dry run: `php spark db:seed CementAppSeeder` with environment `CEMENT_SEED_DRY_RUN=1`.
6. Run `php spark db:seed CementAppSeeder` without the dry-run variable. It inserts only missing catalog definitions, ID-resolves modules, RecordTypes, routes and portals, then commits once.
7. Run your existing MetaForge **SystemCatalog rebuild/sync after commit**, refresh authorized role/route assignments, and allow tenant Sync to deliver newly authorized definitions to the cement frontend.
8. Merge `InstitutionPolicyCatalog::definitions()` into your institution settings RecordType using an authorized metadata mutation (do not create a second institution/settings repository). Apply individual values through the institution's normal configuration mutation.
9. Provision/authorize users, institution-specific roles and portals through MetaForge authentication. The supplied `role_templates.json` is a reference contract, not a bypass of server-side permissions.
10. Register and implement the referenced service handlers before enabling service subscriptions; see below.

### Windows / XAMPP PowerShell example

```powershell
$env:CEMENT_RECORD_PHYSICAL_TABLE_CODE = "your_actual_tenant_physical_table_code"
$env:CEMENT_SEED_DRY_RUN = "1"
php spark db:seed CementAppSeeder
Remove-Item Env:\CEMENT_SEED_DRY_RUN
php spark db:seed CementAppSeeder
```

### Linux/macOS shell example

```bash
export CEMENT_RECORD_PHYSICAL_TABLE_CODE=your_actual_tenant_physical_table_code
CEMENT_SEED_DRY_RUN=1 php spark db:seed CementAppSeeder
php spark db:seed CementAppSeeder
```

## Run-time service safety

**IMPORTANT: This is a complete catalog seeder delivery, not a complete service implementation.** The metadata declares all 28 service interfaces and subscriptions, but does not claim to provide handlers for posting, stock valuation, pricing, approvals, payroll, allocations, report emails or exports.

- Default seeding **does not attach runtime subscriptions or related actions**, so the app will not attempt to execute missing handlers. The declarations remain available for registration and authorized activation.
- To explicitly activate the subscriptions and related actions on a **fresh install**, set `CEMENT_BIND_SERVICE_SUBSCRIPTIONS=1`; the installer first verifies that every declared trusted PHP service handler and its `execute` method are available. It throws before writing if any are missing.
- Service record persistence is optional because MetaForge supports a separate registered service catalog. If your implementation uses a service-registration RecordType and it is configured correctly, set `CEMENT_SEED_SERVICE_RECORDS=1` and `CEMENT_SERVICE_RECORDTYPE_CODE=<your-existing-registration-RecordType-code>`. The created service records have `status=0` (inactive) pending handler verification. You must review that RecordType schema before turning this on.
- If you seed before services are implemented, later **activate them via an authorized RecordType metadata mutation**, rather than expecting an insert-only rerun to overwrite edited definitions.
- Do **not** allow any confirmed sale/loading/movement/payroll to post until its corresponding service is implemented and activated. A seeded form and route are not proof that the accounting/stock operation is safe.

## System boundary and non-duplication

The Cement App reuses `product_category`, `product`, `unit_of_measure`, `price_list`, `price_list_item`; `purchase` and **exactly** `purchaseItem`; and Account/Journal, Bank, User/Role/Portal, plus Cooperative savings and loan repositories where installed. Existing generic definitions are **reused, never overwritten**. All IDs are dynamically looked up, never guessed.

New cement-specific records include `supplier_depot`, `cement_loading`, `loading_clearance`, trip and destination tracking, plus standard inventory/sales/expense collections. Customer and supplier records are generic. Inventory balances are computed, not manually editable through Product.

### Main business invariants

| Area | Contract |
| --- | --- |
| Purchase | Purchase posts Dr supplier prepaid / entitlement GL and Cr bank GL **once**. Supplier codes/PIN/BIN and depot references retained. |
| Purchase item | Product, original quantity, unit price, discounts and net cost become immutable once the first load has occurred. `loadedQty`, `clearedQty`, `deliveredQty` are service-owned rollups. Partial clearance allowed. |
| Cement loading | Confirmed allocation to customers creates sales; allocation to warehouse creates inventory movements; mixed destinations in one load are supported and must commit atomically. |
| Ownership | Defined at Institution settings: `loading-transfer` or `delivery-transfer`, never inferred from a user's UI. |
| Product & pricing | Supplier mapping; unit conversion snapshots; versioned tiers and authorized overrides; price snapshot held on each `customer_sale_item`. |
| Inventory | Configurable keeping method `fixed`, `daily`, `weekly`, `monthly`, `yearly`, `manual_stocktaken`; valuation `fifo` or `weighted_average`. Approval for stock adjustment; affected `inventory_stock` updated only from confirmed/effective movement by related action, supported by service-computed balances. |
| Trips | Each trip has a truck, person/driver and many `trip_destination` records; fuel, maintenance and allocated trip expenses inform margin. |
| Incentives | Supplier scheme optional, or actual benefit recorded directly per purchase/loading. |
| Staff | `staff_employment` links `person`; payroll, payroll items and payments; savings/loan deductions reference Cooperative `member_account` rather than a parallel loan engine. |
| Reporting | Frontend calculation or `server_stored` report result; exporter/email/schedule services are registrations pending implementation. |

## Migrations and compatibility

- This package targets the **final locked RecordType/Route/Portal architecture**; Pages are deliberately absent. An old MetaForge `RecordTypeDefinition(5).php` snapshot from 2026-11-12 used keys such as `relatedRTaction`, `searchmap` and `sunique`, which are **not equivalent** to the newer grouped uniqueness and lookup contracts. The bootstrap will refuse that schema. Migrate it deliberately first.
- The `mf_system` table must have globally unique `search1` enforced by a **database index**, not merely a pre-insert query. The installer rejects code clashes it sees and relies on the DB constraint for concurrent writers.
- System/catalog seed operations are **not** tenant mutations; they do not write tenant ledger rows and cannot replace Mutation API history, audit, idempotency or transactional outbox processing.
- `CEMENT_STRICT_EXISTING=1` causes seeding to fail if an existing reusable RecordType is missing fields declared by this catalog. The default preserves existing definition edits and emits warnings.
- Field descriptors assume the newer canonical `properties.persistent`, `properties.readOnly` and nested `properties.items` metadata; align your live schema adapter if it differs.
- The portal/route RecordType layout codes (`collection`, `record_form`, `record_view`, `dashboard`, `importer`, etc.) must be registered on your frontend. Actual authorization comes from MetaForge after login; portal navigation alone is not a permission grant.
- Client mutation and Sync payloads must use the **exact field codes** in the generated registries; never remap field names in controllers.

## Files of interest

- `app/Database/Seeds/CementAppSeeder.php` — CI4 CLI entrypoint.
- `app/Database/Seeds/Cement/CementCatalog.php` — typed registry of all declaration seeders.
- `app/Database/Seeds/Cement/Support/CementMetadataBuilder.php` — converts specs into MetaForge final RecordType metadata.
- `app/Database/Seeds/Cement/Support/CementCatalogApplier.php` — bootstrap-safe inserter and ID resolver.
- `app/Database/Seeds/Cement/InstitutionPolicyCatalog.php` — institution ownership, inventory and approval settings.
- `app/Database/Seeds/Cement/RoleTemplateCatalog.php` — role templates (authorization still server-side).
- `resources/cement/*.json` — inspectable registration records and source field names.
- `tests/catalog_validate.php` — offline PHP contract verification without a live database.

## Scope disclaimer

This ZIP provides generated, PHP-syntax-checked complete **catalog seeders** based on the agreed Cement App business scope. It has **not** been run against your live MetaForge CI4 schema/database. Some final metadata keys may still need aligning with whichever exact latest `RecordTypeDefinition.php` and registered service API is deployed. In particular, runtime handlers, role permission mutations, service activation, catalog cache rebuild, tenant sample transactions, and production integration tests are separate integration steps. The installer fails safely rather than guessing on those points.

## Institution starter report import (optional)

`TenantStarterMutationFactory::reportMutations($institutionId, $reportRecordTypeId)` prepares all 20 report-definition **Mutation API envelopes** with deterministic UUIDv5 request IDs so an authorized installer can retry safely. This factory does not silently import them: the authorized MetaForge session determines institution scope. `mergeInstitutionSettings($currentSettings)` prepares default institution settings without overwriting existing custom values. Neither operation writes tenant data outside the Mutation API.
