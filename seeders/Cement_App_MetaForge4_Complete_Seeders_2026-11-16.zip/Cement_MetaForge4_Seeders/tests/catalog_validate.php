<?php

declare(strict_types=1);

// Pure-PHP catalog contract checks. No database, vendor, CodeIgniter or network required.
namespace CodeIgniter\Database {
    abstract class Seeder { public function run() {} }
}
namespace {
    use App\Database\Seeds\Cement\CementCatalog;
    use App\Database\Seeds\Cement\Support\CementMetadataBuilder;

    spl_autoload_register(static function(string $class): void {
        $prefix='App\\Database\\Seeds\\Cement\\';
        if (!str_starts_with($class,$prefix)) return;
        $rel = str_replace('\\', DIRECTORY_SEPARATOR, substr($class,strlen($prefix)));
        $file = dirname(__DIR__).'/app/Database/Seeds/Cement/'.$rel.'.php';
        if (is_file($file)) require_once $file;
    });
    function check(bool $truth,string $error): void {if (!$truth) throw new \RuntimeException($error);}

    $types=CementCatalog::recordTypes();
    $modules=CementCatalog::modules();
    $services=CementCatalog::serviceRegistrations();
    $routes=CementCatalog::routes();
    $portals=CementCatalog::portals();
    check(count($types)>=45,'Incomplete RecordType catalog');
    check(count($modules)===10,'Expected 10 modules');
    check(count($services)>=25,'Incomplete service registrations');
    check(count($portals)===7,'Expected 7 portals');
    $typeIds = array_fill_keys(array_keys($types),1001);
    $typeIds += array_fill_keys(['account','account_type','journal','journal_line','bank_account','member','member_account'],1999);
    foreach($types as $code=>$spec) {
        check($code===$spec['code'],'RecordType catalog key mismatch '.$code);
        check(isset($modules[$spec['module']]),'Invalid module '.$code);
        $fieldCodes=array_column($spec['fields'],'code');
        check(count($fieldCodes)===count(array_unique($fieldCodes)), 'Duplicate fields in '.$code);
        check(in_array('status',$fieldCodes,true),'Missing status field in '.$code);
        foreach ($spec['fields'] as $f) {
            check(in_array($f['type'],['string','integer','number','boolean','date','datetime','reference','array','object'],true),'Unrecognized type '.$code.'.'.$f['code']);
            if ($f['type']==='reference') {
                check(isset($typeIds[$f['target']]),'Missing target type '.$code.'.'.$f['code'].' -> '.$f['target']);
            }
        }
        $def=CementMetadataBuilder::recordType($spec,20,30,$typeIds,false);
        check($def['code']===$code,'Definition code mismatch '.$code);
        check(count($def['fields'])===count($spec['fields']),'Field mapper mismatch '.$code);
        check(count($def['searchColumnsMapping'])<=8,'Too many search indexes for '.$code);
        check($def['services']===[] && $def['relatedActions']===[],'Unimplemented handlers unexpectedly activated for '.$code);
        foreach ($def['uniques'] as $unique) {
            foreach ($unique['fields'] as $fieldCode) {
                check(isset($def['searchColumnsMapping'][$fieldCode]),'Unique field not indexed '.$code.'.'.$fieldCode);
            }
        }
        foreach ($def['fields'] as $f) {
            check(is_string($f['code']) && array_key_exists('persistent',$f['properties']),'Incorrect property format '.$code);
            if ($f['type']==='reference') check(($f['recordTypeId']??0)>0,'Unresolved field reference '.$code.'.'.$f['code']);
        }
        if (isset($spec['lifecycle'])) {
            $statusField=array_values(array_filter($def['fields'],static fn($x)=>$x['code']==='status'))[0];
            check($statusField['default']===$spec['lifecycle']['initialState'],'Initial status default mismatch '.$code);
        }
    }
    foreach (['product','product_category','unit_of_measure','price_list','price_list_item','purchase','purchaseItem','cement_loading','inventory_stock','inventory_movement','inventory_stocktake','stock_adjustment','customer_sales','customer_sale_item','trip','trip_destination','payroll','payroll_item','payroll_payment','report','report_result'] as $code) {
        check(isset($types[$code]),'Missing locked RecordType '.$code);
    }
    check(!isset($types['cement_product']),'Do not create a Cement-only Product RT');
    check(!isset($types['staff_loan']),'Do not duplicate Cooperative loan roots');
    check(!isset($types['journal']),'Do not duplicate accounting journal roots');
    $routeCodes = array_column($routes,'code');
    check(count($routeCodes)===count(array_unique($routeCodes)),'Duplicate route codes');
    foreach($routes as $route) {
        check($route['mode']==='open_layout','Unsupported route mode');
        if ($route['targetRecordTypeCode']!==null)check(isset($types[$route['targetRecordTypeCode']]),'Missing route target');
        if (str_ends_with($route['code'],'.edit'))check(($route['parameters'][0]['name']??null)==='recordId','Edit route missing recordId parameter');
    }
    $roleCodes=[];
    foreach($portals as $portal) {
        check(!in_array($portal['code'],$roleCodes,true),'Duplicate portals');
        $roleCodes[]=$portal['code'];
        $allowed=$portal['routes'];
        check(count($allowed)===count(array_unique($allowed)),'Duplicate portal route list');
        foreach($allowed as $code)check(in_array($code,$routeCodes,true),'Portal references unknown route '.$code);
        $walk=static function(array $nav) use (&$walk,$allowed):void {
            foreach($nav as $item) {
                if (isset($item['routeCode'])) check(in_array($item['routeCode'],$allowed,true),'Portal navigation route not in authorized candidate list: '.$item['routeCode']);
                if(isset($item['children']))$walk($item['children']);
            }
        };
        $walk($portal['navigation']);
    }
    $reportMutations=\App\Database\Seeds\Cement\TenantStarterMutationFactory::reportMutations(123,456);
    check(count($reportMutations)===20,'Expected 20 report mutations');
    check(count(array_unique(array_column($reportMutations,'requestId')))===20,'Report request IDs not unique');
    foreach($reportMutations as $row) {
        check(preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-5[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/',$row['requestId'])===1,'Not an RFC4122 v5 UUID');
    }
    check($reportMutations===\App\Database\Seeds\Cement\TenantStarterMutationFactory::reportMutations(123,456),'Retry request IDs must be deterministic');
    echo "PASS: ".count($types)." RecordTypes; ".count($modules)." modules; ".count($services)." service registrations; ".count($routes)." routes; ".count($portals)." portals.\n";
}
